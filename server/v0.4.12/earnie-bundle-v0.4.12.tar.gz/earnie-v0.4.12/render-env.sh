#!/usr/bin/env bash
# Render the project .env that docker compose reads on its own, so a plain
# `docker compose up` in this directory is always correct: tenant.env, plus
# what can be derived from the bundle and the host, after checking the values
# a container would otherwise only reject behind --wait.
set -euo pipefail
cd "$(dirname "$0")"
[ -f tenant.env ] || { echo "tenant.env not found: run ./install.sh, or cp tenant.env.example tenant.env and fill it in" >&2; exit 1; }

queued_modules="crypto ai"
known_modules="oss crypto ai enrichment"
# Release toggles (ADR 0099); platform/features/features.tsv is the registry and
# a test keeps this list equal to it.
known_features="cra"
max_sandbox_cpus=14

# The last line wins, as it does for compose.
read_var() { sed -n "s/^$1=//p" tenant.env | tail -1; }
fail() { echo "$*" >&2; exit 1; }
modules=$(read_var EARNIE_MODULES)
onprem=$(read_var EARNIE_ONPREM_POSTGRES)
otlp_endpoint=$(read_var EARNIE_OTLP_ENDPOINT)
host=$(read_var EARNIE_HOST)
admin_email=$(read_var EARNIE_INITIAL_ADMIN_EMAIL)
[ -n "$host" ] || fail "EARNIE_HOST is required: the DNS name users type, such as earnie.example.com"
printf '%s' "$host" | grep -qE '^[A-Za-z0-9.-]+$' || fail "EARNIE_HOST must be a bare DNS name such as earnie.example.com, no https://, path or spaces, got '$host'"
[ -n "$modules" ] || fail "EARNIE_MODULES is required: comma-separated modules, such as oss,crypto"
case ",$modules," in *[[:space:]]*|*,,*) fail "EARNIE_MODULES must be comma-separated without spaces or empty entries, got '$modules'" ;; esac
for module in $(printf '%s' "$modules" | tr ',' ' '); do
  case " $known_modules " in *" $module "*) ;; *) fail "EARNIE_MODULES has '$module'; the modules are $(printf '%s' "$known_modules" | tr ' ' ','), comma-separated without spaces" ;; esac
done
# The api stops at start-up on a feature it does not know; say so here, with the list.
preview_features=$(read_var EARNIE_PREVIEW_FEATURES)
if [ -n "$preview_features" ]; then
  case ",$preview_features," in *[[:space:]]*|*,,*) fail "EARNIE_PREVIEW_FEATURES must be comma-separated without spaces or empty entries, got '$preview_features'" ;; esac
  for feature in $(printf '%s' "$preview_features" | tr ',' ' '); do
    case " $known_features " in *" $feature "*) ;; *) fail "EARNIE_PREVIEW_FEATURES has '$feature'; the features are $(printf '%s' "$known_features" | tr ' ' ','), comma-separated without spaces" ;; esac
  done
fi
db_url=$(read_var DB_URL)
[ -n "$db_url" ] || fail "DB_URL is required: postgres://user:password@host:5432/db, or run ./install.sh to use the bundled postgres"
db_host=$(printf '%s' "$db_url" | sed -E 's|^[a-z]+://([^@/]*@)?([^:/?]+).*|\2|')
case "$db_host" in localhost|127.0.0.1|::1) fail "DB_URL points at $db_host, which inside a container is the container itself: use the server's address on the docker bridge (DOCKER_BRIDGE_IP in .env, usually 172.17.0.1) or its DNS name" ;; esac
onprem=${onprem:-$([ "$db_host" = postgres ] && echo true || echo false)}
has_module() { case ",${modules}," in *,"$1",*) return 0 ;; esac; return 1; }

# What the api refuses at start-up, said here with the fix. Lengths are
# measured as compose reads them: a $$ in the file is one $.
jwt_secret=$(read_var JWT_SECRET); jwt_secret=${jwt_secret//\$\$/\$}
[ "${#jwt_secret}" -ge 32 ] || fail "JWT_SECRET must be at least 32 characters; ./install.sh generates one when it is empty"
for kek in EARNIE_SSO_KEK_HEX EARNIE_INTEGRATIONS_KEK_HEX; do
  printf '%s' "$(read_var "$kek")" | grep -qE '^[0-9a-fA-F]{64}$' || fail "$kek must be exactly 64 hex characters; ./install.sh generates one when it is empty"
done
# Optional: the api boots without it and disables notification channels, but a
# value that is set and malformed stops it.
notifications_kek=$(read_var EARNIE_NOTIFICATIONS_KEK_HEX)
if [ -n "$notifications_kek" ]; then
  printf '%s' "$notifications_kek" | grep -qE '^[0-9a-fA-F]{64}$' || fail "EARNIE_NOTIFICATIONS_KEK_HEX must be empty or exactly 64 hex characters"
fi
admin_password=$(read_var EARNIE_INITIAL_ADMIN_PASSWORD); admin_password=${admin_password//\$\$/\$}
if [ -n "$admin_password" ]; then
  [ "${#admin_password}" -ge 12 ] && [ "${#admin_password}" -le 128 ] || fail "EARNIE_INITIAL_ADMIN_PASSWORD must be 12 to 128 characters"
  [ -n "$admin_email" ] || fail "EARNIE_INITIAL_ADMIN_EMAIL is required with EARNIE_INITIAL_ADMIN_PASSWORD"
fi
oidc_set=0
for key in OIDC_ISSUER OIDC_CLIENT_ID OIDC_CLIENT_SECRET; do [ -n "$(read_var "$key")" ] && oidc_set=$((oidc_set + 1)); done
[ "$oidc_set" -eq 0 ] || [ "$oidc_set" -eq 3 ] || fail "OIDC_ISSUER, OIDC_CLIENT_ID and OIDC_CLIENT_SECRET go together: set all three or none"
if [ "$(read_var EARNIE_PASSWORD_AUTH_ENABLED)" != "true" ] && [ "$oidc_set" -eq 0 ]; then
  fail "nobody could sign in: set EARNIE_PASSWORD_AUTH_ENABLED=true with the first admin's email and password, or the three OIDC_* values"
fi

# Caddy pastes SCANS_MAX_UPLOAD_MB into its body cap as text, and the api
# refuses to start on a value it cannot read, so both see only this format.
for knob in SCANS_MAX_UPLOAD_MB SCANS_MAX_SBOM_MB SCANS_UPLOAD_TIMEOUT_SECONDS; do
  value=$(read_var "$knob")
  if [ -n "$value" ] && ! printf '%s' "$value" | grep -qE '^[1-9][0-9]{0,6}$'; then
    fail "$knob must be empty or a whole number from 1 to 9999999, got '$value'"
  fi
done

# Caddy imports the snippet tls_<EARNIE_TLS>, so a typo would only surface as
# a crash loop behind --wait. Refuse it here, with the files each mode reads.
# Empty means custom when the operator has put both files in place, else acme.
data_dir=$(read_var EARNIE_DATA_DIR)
tls_dir=$(read_var EARNIE_TLS_DIR)
tls_dir=${tls_dir:-${data_dir:-/var/lib/earnie}/tls}
tls_mode=$(read_var EARNIE_TLS)
if [ -d "$tls_dir" ] && [ ! -r "$tls_dir" ]; then fail "$tls_dir exists but cannot be read: sudo chmod 755 $tls_dir"; fi
if [ -z "$tls_mode" ]; then
  if [ -s "$tls_dir/cert.pem" ] && [ -s "$tls_dir/key.pem" ]; then tls_mode=custom; else tls_mode=acme; fi
fi
acme_email=$(read_var EARNIE_ACME_EMAIL)
case "$tls_mode" in
  acme)
    acme_email=${acme_email:-$admin_email}
    [ -n "$acme_email" ] || fail "EARNIE_TLS=acme needs a contact address for Let's Encrypt: set EARNIE_ACME_EMAIL or EARNIE_INITIAL_ADMIN_EMAIL"
    case "$host" in
      *.local|*.internal|*.lan|*.corp|*.home|*.localdomain) internal=1 ;;
      *.*) internal=0; printf '%s' "$host" | grep -qE '^([0-9]+\.){3}[0-9]+$' && internal=1 ;;
      *) internal=1 ;;
    esac
    [ "$internal" = 0 ] || echo "note: $host looks internal, but Let's Encrypt needs a public name that resolves to this server with ports 80 and 443 open; for an internal name put cert.pem and key.pem in $tls_dir" >&2
    ;;
  custom)
    for file in cert.pem key.pem; do
      [ -s "$tls_dir/$file" ] || fail "EARNIE_TLS=custom needs $tls_dir/$file: the full certificate chain in cert.pem, its unencrypted key in key.pem"
    done
    ;;
  proxy)
    # A TLS proxy on this host holds the certificate; Caddy only listens on
    # the loopback, so its port must be one no other tenant here uses.
    acme_email=""
    ;;
  *)
    fail "EARNIE_TLS must be acme, custom or proxy, got '$tls_mode'"
    ;;
esac

# The host ports and sandbox names each tenant on a shared host keeps apart.
for knob in CADDY_HTTP_PORT CADDY_HTTPS_PORT API_BRIDGE_PORT EARNIE_FLUENTD_PORT; do
  value=$(read_var "$knob")
  if [ -n "$value" ] && ! { printf '%s' "$value" | grep -qE '^[1-9][0-9]{0,4}$' && [ "$value" -le 65535 ]; }; then
    fail "$knob must be empty or a port from 1 to 65535, got '$value'"
  fi
done
if [ "$tls_mode" = proxy ] && [ -z "$(read_var CADDY_HTTP_PORT)" ]; then
  fail "EARNIE_TLS=proxy needs CADDY_HTTP_PORT: the loopback port the host's TLS proxy forwards this tenant to"
fi
sandbox_network=$(read_var SCANS_SANDBOX_NETWORK)
if [ -n "$sandbox_network" ] && ! printf '%s' "$sandbox_network" | grep -qE '^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,62}$'; then
  fail "SCANS_SANDBOX_NETWORK must be a Docker network name such as earnie-sandbox, got '$sandbox_network'"
fi
# iptables names a chain in at most 28 characters, and the script adds -NAT.
egress_chain=$(read_var SANDBOX_EGRESS_CHAIN)
if [ -n "$egress_chain" ] && ! printf '%s' "$egress_chain" | grep -qE '^[A-Z][A-Z0-9-]{0,23}$'; then
  fail "SANDBOX_EGRESS_CHAIN must be 1 to 24 capital letters, digits or dashes, such as EARNIE-SANDBOX, got '$egress_chain'"
fi

# The release: tenant.env, else the bundle's VERSION file. Both set and
# different would run one release's images on another's compose.
version=$(read_var EARNIE_VERSION)
bundle_version=$(cat VERSION 2>/dev/null || true)
if [ -n "$version" ] && [ -n "$bundle_version" ] && [ "$version" != "$bundle_version" ]; then
  fail "tenant.env says EARNIE_VERSION=$version but this bundle is $bundle_version: leave EARNIE_VERSION empty to run the bundle's release"
fi
version=${version:-$bundle_version}
[ -n "$version" ] || fail "EARNIE_VERSION is required: this directory has no VERSION file, so name the release to run, such as v1.2.3"

# Host facts the workers and the sandbox need, on every tenant: worker-deps
# resolves dependency trees in the sandbox whatever the modules. The docker
# group id and the bridge address differ between hosts; a sandbox asked for
# more cores than the host has never starts (docker refuses --cpus above the
# count).
docker_gid=$(read_var DOCKER_GID)
socket_gid=$(stat -c %g /var/run/docker.sock 2>/dev/null || true)
if [ -n "$docker_gid" ] && [ -n "$socket_gid" ] && [ "$docker_gid" != "$socket_gid" ]; then
  fail "DOCKER_GID=$docker_gid but /var/run/docker.sock belongs to group $socket_gid, so the workers could not use it: leave DOCKER_GID empty"
fi
docker_gid=${docker_gid:-$socket_gid}
docker_gid=${docker_gid:-$(getent group docker 2>/dev/null | cut -d: -f3)}
if [ -z "$docker_gid" ]; then fail "DOCKER_GID is required: this host has no docker group and no /var/run/docker.sock to read it from"; fi
bridge_ip=$(read_var DOCKER_BRIDGE_IP)
host_bridge=$(docker network inspect bridge --format '{{range .IPAM.Config}}{{.Gateway}} {{end}}' 2>/dev/null | grep -oE '([0-9]+\.){3}[0-9]+' | head -1 || true)
if [ -n "$bridge_ip" ] && [ -n "$host_bridge" ] && [ "$bridge_ip" != "$host_bridge" ]; then
  fail "DOCKER_BRIDGE_IP=$bridge_ip but this host's docker bridge is $host_bridge, so the sandbox could not reach the api: leave DOCKER_BRIDGE_IP empty"
fi
bridge_ip=${bridge_ip:-${host_bridge:-172.17.0.1}}
docker_cli=$(read_var DOCKER_CLI)
docker_cli=${docker_cli:-$(command -v docker || echo /usr/bin/docker)}
host_cpus=$(nproc 2>/dev/null || echo "$max_sandbox_cpus")
sandbox_cpus=$(read_var SANDBOX_CPUS)
if [ -z "$sandbox_cpus" ]; then
  sandbox_cpus=$(( host_cpus < max_sandbox_cpus ? host_cpus : max_sandbox_cpus ))
elif has_module crypto && [ "${sandbox_cpus%%.*}" -gt "$host_cpus" ] 2>/dev/null; then
  fail "SANDBOX_CPUS=$sandbox_cpus but this host has $host_cpus CPUs: no dependency build could start. Set it to $host_cpus or less, or leave it empty"
fi
# The resolve sandbox gets 2 cores, or the host's when it has fewer.
max_resolve_cpus=2
resolve_cpus=$(read_var SANDBOX_RESOLVE_CPUS)
if [ -z "$resolve_cpus" ]; then
  resolve_cpus=$(( host_cpus < max_resolve_cpus ? host_cpus : max_resolve_cpus ))
elif [ "${resolve_cpus%%.*}" -gt "$host_cpus" ] 2>/dev/null; then
  fail "SANDBOX_RESOLVE_CPUS=$resolve_cpus but this host has $host_cpus CPUs: no dependency resolution could start. Set it to $host_cpus or less, or leave it empty"
fi
# A worker gets 4 cores, or the host's when it has fewer.
max_worker_cpus=4
worker_crypto_cpus=$(read_var WORKER_CRYPTO_CPUS); worker_ai_cpus=$(read_var WORKER_AI_CPUS)
for pair in crypto:WORKER_CRYPTO_CPUS ai:WORKER_AI_CPUS; do
  cpus=$(read_var "${pair#*:}")
  if has_module "${pair%%:*}" && [ -n "$cpus" ] && [ "${cpus%%.*}" -gt "$host_cpus" ] 2>/dev/null; then
    fail "${pair#*:}=$cpus but this host has $host_cpus CPUs: docker would refuse to start the worker. Set it to $host_cpus or less, or leave it empty"
  fi
done
worker_crypto_cpus=${worker_crypto_cpus:-$(( host_cpus < max_worker_cpus ? host_cpus : max_worker_cpus ))}
# The sandbox and the worker together must fit the host, or a build is OOM-killed.
mib() { # a compose or Kubernetes quantity in MiB
  local n=${1%%[A-Za-z]*} u=${1#"${1%%[A-Za-z]*}"}
  case "$u" in G|g|Gi|GiB) echo $(( ${n%%.*} * 1024 )) ;; M|m|Mi|MiB) echo "${n%%.*}" ;; K|k|Ki) echo $(( ${n%%.*} / 1024 )) ;; "") echo $(( ${n%%.*} / 1048576 )) ;; *) echo 0 ;; esac
}
if has_module crypto && [ -r /proc/meminfo ]; then
  host_mib=$(( $(awk '/^MemTotal:/ { print $2 }' /proc/meminfo) / 1024 ))
  sandbox_mem=$(read_var SANDBOX_MEMORY); worker_mem=$(read_var WORKER_CRYPTO_MEM_LIMIT)
  need_mib=$(( $(mib "${sandbox_mem:-12Gi}") + $(mib "${worker_mem:-8g}") ))
  [ "$need_mib" -le "$host_mib" ] || fail "crypto needs SANDBOX_MEMORY (${sandbox_mem:-12Gi}) plus WORKER_CRYPTO_MEM_LIMIT (${worker_mem:-8g}) = $(( need_mib / 1024 )) GiB but this host has $(( host_mib / 1024 )) GiB: use a host with 32 GB, or lower both in tenant.env"
fi
worker_ai_cpus=${worker_ai_cpus:-$(( host_cpus < max_worker_cpus ? host_cpus : max_worker_cpus ))}

profiles=""
derived="COMPOSE_PROFILES|COMPOSE_FILE|EARNIE_TELEMETRY_SCRAPE_TARGETS|EARNIE_VERSION|EARNIE_TLS|EARNIE_ACME_EMAIL|EARNIE_ONPREM_POSTGRES|DOCKER_GID|DOCKER_BRIDGE_IP|DOCKER_CLI|SANDBOX_CPUS|SANDBOX_RESOLVE_CPUS|SCANS_DEPGRAPH_QUEUED|WORKER_CRYPTO_CPUS|WORKER_AI_CPUS"
scrape_targets='"earnie-api:8080","worker-deps:9090"'
queued_env="SCANS_DEPGRAPH_QUEUED=true"$'\n'
summary=""
for module in $queued_modules; do
  queued=false
  if has_module "$module"; then
    queued=true; profiles="${profiles:+$profiles,}$module"; scrape_targets="$scrape_targets,\"worker-$module:9090\""
  fi
  var="SCANS_$(printf '%s' "$module" | tr '[:lower:]' '[:upper:]')_QUEUED"
  derived="$derived|$var"
  queued_env="$queued_env$var=$queued"$'\n'
  summary="$summary ${module}_queued=$queued"
done
if [ "$onprem" = "true" ]; then
  [ -n "$(read_var ONPREM_PG_PASSWORD)" ] || fail "ONPREM_PG_PASSWORD is required with EARNIE_ONPREM_POSTGRES=true; ./install.sh generates it when both are empty"
  profiles="${profiles:+$profiles,}onprem"
fi
compose_file="compose.yaml"
[ "$tls_mode" != proxy ] || compose_file="$compose_file:compose.proxy.yaml"
if [ -n "$otlp_endpoint" ]; then
  profiles="${profiles:+$profiles,}telemetry"
  compose_file="$compose_file:compose.logs.yaml"
fi

umask 077
{
  grep -vE "^($derived)=" tenant.env
  echo "COMPOSE_PROFILES=${profiles}"
  echo "COMPOSE_FILE=${compose_file}"
  echo "EARNIE_TELEMETRY_SCRAPE_TARGETS=[${scrape_targets}]"
  echo "EARNIE_VERSION=${version}"
  echo "EARNIE_TLS=${tls_mode}"
  echo "EARNIE_ACME_EMAIL=${acme_email}"
  echo "EARNIE_ONPREM_POSTGRES=${onprem}"
  echo "DOCKER_GID=${docker_gid}"
  echo "DOCKER_BRIDGE_IP=${bridge_ip}"
  echo "DOCKER_CLI=${docker_cli}"
  echo "SANDBOX_CPUS=${sandbox_cpus}"
  echo "SANDBOX_RESOLVE_CPUS=${resolve_cpus}"
  echo "WORKER_CRYPTO_CPUS=${worker_crypto_cpus}"
  echo "WORKER_AI_CPUS=${worker_ai_cpus}"
  printf '%s' "$queued_env"
} > .env.tmp
mv .env.tmp .env
echo "rendered .env: version=${version} tls=${tls_mode} profiles=${profiles:-none} files=${compose_file}${summary} docker_gid=${docker_gid} bridge=${bridge_ip} sandbox_cpus=${sandbox_cpus} resolve_cpus=${resolve_cpus}"
