#!/usr/bin/env bash
# Print every image this bundle can start for one release, one per line.
#
#   ./images.sh v1.2.3
#
# release.yml saves exactly this list into the on-prem image archive. It reads
# the images from compose.yaml with every profile on, so a new service or
# profile lands in the archive without a second list to keep in sync.
#
# The ai profile is left out: whether on-prem ships earnie-api-ai, which
# carries ai-finder-pro and ai-fingerprint as readable Python, is not decided.
set -euo pipefail
version="${1:?usage: images.sh vX.Y.Z}"
bundle=$(cd "$(dirname "$0")" && pwd)
excluded_profiles="ai"

work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cp -r "$bundle/." "$work/"
cp "$work/tenant.env.example" "$work/tenant.env"
rm -f "$work/.env"

export EARNIE_VERSION="$version" EARNIE_HOST=images.invalid EARNIE_ACME_EMAIL=images@images.invalid
cd "$work"
all_profiles=$(docker compose config --profiles)
profiles=()
for profile in $all_profiles; do
  case " $excluded_profiles " in *" $profile "*) continue ;; esac
  profiles+=(--profile "$profile")
done
docker compose "${profiles[@]}" config --images | sort -u
