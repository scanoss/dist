#!/usr/bin/env bash
# Live test for sandbox egress (#1089). Starts the bundle's real sandbox-egress
# service against this host's firewall, then runs a sandbox-shaped container on
# the confined subnet and checks what it can reach. It changes the host's
# iptables, so it is not part of `make ci`: run it on a disposable VM or a
# workstation you own, with `make test-sandbox-egress-live`.
#
#   EARNIE_API_IMAGE  an earnie-api image that carries iptables (required); it
#                     also plays the staging endpoint and the sandbox, so nothing is pulled
set -euo pipefail
: "${EARNIE_API_IMAGE:?set EARNIE_API_IMAGE to an earnie-api image with iptables}"
image=$EARNIE_API_IMAGE
repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
work=$(mktemp -d)
cp -r "$repo_root/deploy/compose/." "$work/"
project=earnie-egress-live
subnet=172.31.248.0/24
old_subnet=172.31.247.0/24
staging_ip=172.31.246.1
staging_net=earnie-egress-live-staging
sandbox_net=earnie-egress-live-sandbox

compose() { (cd "$work" && docker compose --project-name "$project" "$@"); }
guard() { compose exec -T sandbox-egress sh /opt/earnie/sandbox-egress.sh "$@"; }
# shellcheck disable=SC2016 # expanded inside the container
pick='for b in iptables-nft iptables-legacy; do $b -w -n -L DOCKER-USER >/dev/null 2>&1 && break; done'
ipt() { compose exec -T sandbox-egress sh -c "$pick; \$b -w \"\$@\"" ipt "$@"; }
set_env() {
  if grep -q "^$1=" "$work/tenant.env"; then sed -i "s#^$1=.*#$1=$2#" "$work/tenant.env"; else echo "$1=$2" >>"$work/tenant.env"; fi
  (cd "$work" && ./render-env.sh >/dev/null)
}

cleanup() {
  set +e
  set_env SCANS_SANDBOX_SUBNET ""
  compose run --rm -T --no-deps --entrypoint sh sandbox-egress -c "$pick
    sh /opt/earnie/sandbox-egress.sh apply
    for c in EARNIE-SANDBOX EARNIE-SANDBOX-IN; do \$b -w -F \$c; \$b -w -X \$c; done
    \$b -w -t nat -F EARNIE-SANDBOX-NAT; \$b -w -t nat -X EARNIE-SANDBOX-NAT" >/dev/null 2>&1
  compose down -v >/dev/null 2>&1
  docker rm -f earnie-egress-live-staging >/dev/null 2>&1
  docker network rm "$sandbox_net" "$staging_net" >/dev/null 2>&1
  rm -rf "$work"
}
trap cleanup EXIT

# A stand-in for the api's published staging port, on its own bridge and port
# so it never collides with an api already listening on 8080.
staging_port=18080
sed -i "s#\(SCANS_SANDBOX_STAGING_URL: http://\${DOCKER_BRIDGE_IP:-172.17.0.1}\):8080#\1:$staging_port#" "$work/compose.yaml"
docker network create --subnet 172.31.246.0/24 "$staging_net" >/dev/null
docker run -d --name earnie-egress-live-staging --network "$staging_net" -p "$staging_ip:$staging_port:8000" \
  --entrypoint python3 "$image" -m http.server 8000 >/dev/null

cp "$work/tenant.env.example" "$work/tenant.env"
set_env EARNIE_MODULES oss,crypto
set_env EARNIE_API_IMAGE "$EARNIE_API_IMAGE"
set_env DOCKER_BRIDGE_IP "$staging_ip"
set_env SCANS_SANDBOX_MIRROR_CIDRS 10.254.254.0/24
set_env SCANS_SANDBOX_SUBNET "$old_subnet"
compose up -d --wait sandbox-egress >/dev/null
# Re-point it at a new subnet, as an operator editing tenant.env would.
set_env SCANS_SANDBOX_SUBNET "$subnet"
compose up -d --wait sandbox-egress >/dev/null
guard apply
guard apply

failures=0
expect() {
  if [ "$1" = "$2" ]; then echo "ok    $3"; else echo "FAIL  $3 (got $2, want $1)"; failures=$((failures + 1)); fi
}

expect 1 "$(ipt -S DOCKER-USER | grep -c -- '-j EARNIE-SANDBOX$')" "one DOCKER-USER jump after three applies"
expect 0 "$(ipt -S DOCKER-USER | grep -c -- "-s $old_subnet")" "the previous subnet's jump is gone"
expect 1 "$(ipt -t nat -S POSTROUTING | grep -c -- '-j EARNIE-SANDBOX-NAT$')" "one NAT jump"
expect 0 "$(guard check >/dev/null; echo $?)" "check reports the rules in place"

# The worker creates the network this way (CLIDockerRunner.EnsureNetwork).
docker network create --driver bridge --subnet "$subnet" --ipv6=false \
  -o com.docker.network.bridge.enable_ip_masquerade=false "$sandbox_net" >/dev/null

reach() {
  docker run --rm --network "$sandbox_net" --cap-drop ALL --security-opt no-new-privileges --entrypoint curl "$image" \
    -s -o /dev/null -w '%{http_code}' --max-time 10 "$1" 2>/dev/null || true
}
expect 200 "$(reach https://repo.maven.apache.org/maven2/)" "Maven Central is reachable"
expect 200 "$(reach https://pypi.org/simple/)" "PyPI is reachable"
expect 200 "$(reach https://proxy.golang.org/golang.org/x/text/@v/list)" "the Go proxy is reachable"
expect 200 "$(reach https://index.crates.io/config.json)" "crates.io is reachable"
expect 200 "$(reach "http://$staging_ip:$staging_port/")" "staging is reachable through its published port"
expect 000 "$(reach https://www.wikipedia.org/)" "an arbitrary host is refused"
expect 000 "$(reach http://169.254.169.254/)" "the cloud metadata endpoint is refused"
expect 000 "$(reach "http://${subnet%.0/24}.1:22/")" "the host itself is refused"

[ "$failures" -eq 0 ] || { echo "sandbox egress live: $failures failed"; exit 1; }
echo "sandbox egress live: ok"
