#!/usr/bin/env bash
# Every environment variable the server reads must be documented for the
# operator in tenant.env.example, set by compose.yaml, or listed with a reason
# in env-not-operator.txt. A new os.Getenv without one of those fails here.
set -euo pipefail
repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
bundle="$repo_root/deploy/compose"

read_by_code=$(grep -rhoE '[A-Za-z_.]*([Ee]nv|Getenv|LookupEnv)[A-Za-z_]*\(\s*"[A-Z][A-Z0-9_]+"' \
  --include="*.go" --exclude="*_test.go" --exclude-dir=earniecli "$repo_root/cmd/earnie-api" "$repo_root/platform" "$repo_root/pkg" 2>/dev/null \
  | grep -oE '"[A-Z][A-Z0-9_]+"' | tr -d '"' | sort -u)
documented=$(grep -oE '^#? ?[A-Z][A-Z0-9_]+=' "$bundle/tenant.env.example" | tr -d '# =' | sort -u)
set_by_compose=$(grep -oE '^\s+[A-Z][A-Z0-9_]+:' "$bundle/compose.yaml" | tr -d ' :' | sort -u)
excused=$(grep -vE '^\s*(#|$)' "$bundle/tests/env-not-operator.txt" | awk '{print $1}' | sort -u)

missing=$(comm -23 <(echo "$read_by_code") <(printf '%s\n%s\n%s\n' "$documented" "$set_by_compose" "$excused" | sort -u))
if [ -n "$missing" ]; then
  echo "env inventory: read by the server but neither in tenant.env.example, compose.yaml nor env-not-operator.txt:" >&2
  echo "$missing" | sed 's/^/  /' >&2
  exit 1
fi

stale=$(comm -13 <(echo "$read_by_code") <(echo "$excused"))
if [ -n "$stale" ]; then
  echo "env inventory: excused but no longer read by the server, remove from env-not-operator.txt:" >&2
  echo "$stale" | sed 's/^/  /' >&2
  exit 1
fi
shadowed=$(comm -12 <(echo "$documented") <(echo "$excused"))
if [ -n "$shadowed" ]; then
  echo "env inventory: these keys are excused as set by the image or internal, so tenant.env.example must not list them (an empty KEY= shadows the image ENV):" >&2
  echo "$shadowed" | sed 's/^/  /' >&2
  exit 1
fi
echo "env inventory: ok ($(echo "$read_by_code" | wc -l) variables read, all accounted for)"
