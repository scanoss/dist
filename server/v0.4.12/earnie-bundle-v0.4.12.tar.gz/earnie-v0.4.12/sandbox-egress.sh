#!/bin/sh
# Confine the dependency sandbox's egress on this host (ADR 0088 decision 2,
# ADR 0081, #1089). Runs as the sandbox-egress service: host network, NET_ADMIN.
#
#   sandbox-egress.sh          apply, then re-apply every SANDBOX_EGRESS_INTERVAL seconds
#   sandbox-egress.sh apply    apply once
#   sandbox-egress.sh check    exit 0 only when the host enforces the current rules
#   sandbox-egress.sh rules    print the iptables-restore payload, touch nothing
#
# Builds run on SCANS_SANDBOX_SUBNET. From it, a new connection may reach the
# staging endpoint (SCANS_SANDBOX_STAGING_URL, through the api's published
# port), SCANS_SANDBOX_MIRROR_CIDRS on any port, and the public registry
# ranges in sandbox-registries.txt on 80 and 443. Everything else, the host
# itself included, is refused. The worker creates that network without
# masquerade, so until these rules are in place the subnet has no route out.
# SANDBOX_EGRESS_CHAIN names the chains (default EARNIE-SANDBOX).
set -eu

subnet=${SCANS_SANDBOX_SUBNET:-}
staging_url=${SCANS_SANDBOX_STAGING_URL:-}
mirrors=${SCANS_SANDBOX_MIRROR_CIDRS:-}
registries=${SANDBOX_REGISTRIES_FILE:-$(dirname "$0")/sandbox-registries.txt}
interval=${SANDBOX_EGRESS_INTERVAL:-30}

# Each tenant on a shared host names its own chains: jump() below drops every
# jump to its chains that is not for its own subnet.
chain=${SANDBOX_EGRESS_CHAIN:-EARNIE-SANDBOX}
input_chain=$chain-IN
nat_chain=$chain-NAT

die() { echo "sandbox-egress: $*" >&2; exit 1; }

# Docker installs DOCKER-USER through one of two iptables backends; rules
# written through the other land in tables Docker never consults.
ipt=""
pick_backend() {
  for candidate in iptables-nft iptables-legacy; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -w -n -L DOCKER-USER >/dev/null 2>&1; then
      ipt=$candidate
      return
    fi
  done
  die "no DOCKER-USER chain under iptables-nft or iptables-legacy; is Docker running with its iptables firewall?"
}

staging_host() { printf '%s' "$staging_url" | sed -E 's#^[a-z]+://##; s#[/:].*$##'; }
staging_port() {
  port=$(printf '%s' "$staging_url" | sed -nE 's#^[a-z]+://[^/:]+:([0-9]+).*$#\1#p')
  if [ -n "$port" ]; then echo "$port"; elif [ "${staging_url%%://*}" = https ]; then echo 443; else echo 80; fi
}

list() { printf '%s\n' "$1" | sed -e 's/[, ][, ]*/\n/g' | sed '/^$/d'; }
registry_cidrs() { sed -e 's/#.*//' -e 's/[[:space:]]//g' -e '/^$/d' "$registries"; }

rules() {
  [ -n "$subnet" ] || die "SCANS_SANDBOX_SUBNET is required"
  [ -f "$registries" ] || die "$registries not found"
  host=$(staging_host)
  [ -n "$host" ] || die "SCANS_SANDBOX_STAGING_URL is required"
  echo "*filter"
  echo ":$chain - [0:0]"
  echo ":$input_chain - [0:0]"
  echo "-A $chain -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN"
  echo "-A $chain -p tcp -m conntrack --ctstate DNAT --ctorigdst $host --ctorigdstport $(staging_port) -j RETURN"
  list "$mirrors" | while read -r cidr; do echo "-A $chain -d $cidr -j RETURN"; done
  registry_cidrs | while read -r cidr; do echo "-A $chain -d $cidr -p tcp -m multiport --dports 80,443 -j RETURN"; done
  echo "-A $chain -p tcp -j REJECT --reject-with tcp-reset"
  echo "-A $chain -j REJECT --reject-with icmp-admin-prohibited"
  echo "-A $input_chain -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN"
  echo "-A $input_chain -j REJECT --reject-with icmp-admin-prohibited"
  echo "COMMIT"
  echo "*nat"
  echo ":$nat_chain - [0:0]"
  echo "-A $nat_chain ! -d $subnet -j MASQUERADE"
  echo "COMMIT"
}

# jump TABLE PARENT TARGET: keep exactly one "-s $subnet -j TARGET" at the top
# of PARENT, and drop the jumps a previous subnet left behind.
jump() {
  table=$1 parent=$2 target=$3
  "$ipt" -w -t "$table" -S "$parent" | grep -E -- "-j $target\$" | grep -vF -- "-s $subnet -j $target" |
    while read -r stale; do
      # shellcheck disable=SC2046 # the rule spec is iptables' own -S output
      "$ipt" -w -t "$table" $(printf '%s' "$stale" | sed 's/^-A /-D /')
    done
  [ -z "$subnet" ] && return
  "$ipt" -w -t "$table" -C "$parent" -s "$subnet" -j "$target" 2>/dev/null ||
    "$ipt" -w -t "$table" -I "$parent" 1 -s "$subnet" -j "$target"
}

apply() {
  if [ -n "$subnet" ]; then
    # One restore is one transaction: the chains never sit half-written.
    payload=$(rules)
    printf '%s\n' "$payload" | "$ipt-restore" -w --noflush
  fi
  # The NAT jump is what opens a route out, so it goes last.
  jump filter DOCKER-USER "$chain"
  jump filter INPUT "$input_chain"
  jump nat POSTROUTING "$nat_chain"
}

check() {
  [ -n "$subnet" ] || return 0
  "$ipt" -w -C DOCKER-USER -s "$subnet" -j "$chain" &&
    "$ipt" -w -C INPUT -s "$subnet" -j "$input_chain" &&
    "$ipt" -w -t nat -C POSTROUTING -s "$subnet" -j "$nat_chain" &&
    [ "$("$ipt" -w -S "$chain" | tail -1)" = "-A $chain -j REJECT --reject-with icmp-admin-prohibited" ]
}

case "${1:-run}" in
  rules) rules ;;
  apply) pick_backend; apply ;;
  check) pick_backend; check ;;
  run)
    pick_backend
    apply
    if [ -n "$subnet" ]; then
      echo "sandbox-egress: $subnet confined through $ipt ($(registry_cidrs | wc -l) registry ranges, mirrors: ${mirrors:-none})"
    else
      echo "sandbox-egress: SCANS_SANDBOX_SUBNET is empty; sandbox egress is open"
    fi
    while sleep "$interval"; do apply; done
    ;;
  *) die "usage: $0 [run|apply|check|rules]" ;;
esac
