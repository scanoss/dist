#!/usr/bin/env bash
# Converge the singleton organization, its module toggles and the first admin.
# Runs inside the api image after migrations, on every `compose up`, so every
# step has to be safe to repeat.
set -euo pipefail

: "${EARNIE_ORG_NAME:?EARNIE_ORG_NAME is required}"
: "${EARNIE_MODULES:?EARNIE_MODULES is required (comma-separated module slugs)}"

ensure_args=(--name "$EARNIE_ORG_NAME")
if [ -n "${EARNIE_INITIAL_ADMIN_EMAIL:-}" ]; then
  ensure_args+=(--admin-email "$EARNIE_INITIAL_ADMIN_EMAIL")
fi
/earnie-admin organization ensure "${ensure_args[@]}"
/earnie-admin modules sync --modules "$EARNIE_MODULES"

if [ -n "${EARNIE_INITIAL_ADMIN_EMAIL:-}" ] && [ -n "${EARNIE_INITIAL_ADMIN_PASSWORD:-}" ]; then
  printf '%s\n' "$EARNIE_INITIAL_ADMIN_PASSWORD" | /earnie-admin user set-password "$EARNIE_INITIAL_ADMIN_EMAIL"
fi
echo "bootstrap: organization, modules and admin converged"
