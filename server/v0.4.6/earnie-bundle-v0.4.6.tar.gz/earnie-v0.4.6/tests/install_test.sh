#!/usr/bin/env bash
# install.sh against a fake docker: the preflight messages, what a first run
# derives and generates, that a set value is never changed, that a refused run
# writes nothing, that a second run asks nothing and pulls nothing, that an
# upgrade finds the previous tenant.env, and that an archive is only loaded
# when named.
set -euo pipefail
repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
export FAKE=$work/fake FAKE_LOG=$work/docker.log FAKE_PRESENT=$work/present FAKE_DOCKER_VERSION=29.1.0 FAKE_DOCKER_ROOT=$work FAKE_INFO_RC=0 FAKE_PULL_RC=0 FAKE_CURL_RC=0 FAKE_INSTALLED=""
mkdir -p "$FAKE"
: > "$FAKE_PRESENT"
cat > "$FAKE/docker" <<'SH'
#!/usr/bin/env bash
echo "$*" >> "$FAKE_LOG"
case "$*" in
  "info") exit "$FAKE_INFO_RC" ;;
  "info --format {{.DockerRootDir}}") echo "$FAKE_DOCKER_ROOT" ;;
  "version --format {{.Server.Version}}") echo "$FAKE_DOCKER_VERSION" ;;
  "compose version") exit 0 ;;
  "compose config --images") printf '%s\n' ghcr.io/scanoss/earnie/earnie-api:v9.9.9 ghcr.io/scanoss/earnie/earnie-web:v9.9.9 caddy:2-alpine ;;
  "image inspect "*) grep -qx "$3" "$FAKE_PRESENT" ;;
  "load -i "*) [ -f "$3" ] || { echo "open $3: no such file" >&2; exit 1; }; printf '%s\n' ghcr.io/scanoss/earnie/earnie-api:v9.9.9 ghcr.io/scanoss/earnie/earnie-web:v9.9.9 caddy:2-alpine >> "$FAKE_PRESENT" ;;
  "compose pull") [ "$FAKE_PULL_RC" = 0 ] || { echo "dial tcp: lookup ghcr.io: no such host" >&2; exit "$FAKE_PULL_RC"; }; docker compose config --images >> "$FAKE_PRESENT" ;;
  "manifest inspect "*) exit "${FAKE_MANIFEST_RC:-1}" ;;
  "compose up -d --remove-orphans --wait") exit "${FAKE_UP_RC:-0}" ;;
  "compose ps -a"*) printf '%s\n' "caddy Up 5 seconds (unhealthy)" "web Up 9 seconds (healthy)" "migrate Exited (0)" "worker-crypto Up 9 seconds" "bootstrap Exited (1)" ;;
  "ps -a --filter label=com.docker.compose.project=earnie --filter label=com.docker.compose.service=earnie-api --format "*) echo "${FAKE_INSTALLED:-}" ;;
  "compose logs "*) exit 0 ;;
  "network inspect bridge --format "*) echo "172.18.0.1 " ;;
  *) echo "fake docker: unexpected: $*" >&2; exit 99 ;;
esac
SH
printf '#!/usr/bin/env bash\necho docker:x:988:\n' > "$FAKE/getent"
printf '#!/usr/bin/env bash\necho 8\n' > "$FAKE/nproc"
printf '#!/usr/bin/env bash\necho install-test.example.net\n' > "$FAKE/hostname"
printf '#!/usr/bin/env bash\necho "curl $*" >> "$FAKE_LOG"; exit "$FAKE_CURL_RC"\n' > "$FAKE/curl"
printf '#!/usr/bin/env bash\nexit 0\n' > "$FAKE/sleep"
cat > "$FAKE/stat" <<'SH'
#!/usr/bin/env bash
if [ "$*" = "-c %g /var/run/docker.sock" ]; then echo "${FAKE_SOCKET_GID:-988}"; else exec /usr/bin/stat "$@"; fi
SH
cat > "$FAKE/df" <<'SH'
#!/usr/bin/env bash
echo "Filesystem 1024-blocks Used Available Capacity Mounted on"
echo "fs 1 1 ${FAKE_FREE_KB:-104857600} 1% /"
SH
chmod +x "$FAKE"/*
export PATH="$FAKE:$PATH"
unset EARNIE_HOST SCANOSS_API_KEY EARNIE_INITIAL_ADMIN_EMAIL EARNIE_INITIAL_ADMIN_PASSWORD EARNIE_ORG_NAME EARNIE_MODULES EARNIE_DATA_DIR DB_URL

# A release as the customer extracts it.
release=$work/release
new_bundle() { # version
  mkdir -p "$release/earnie-$1"
  cp -r "$repo_root/deploy/compose/." "$release/earnie-$1/"
  rm -f "$release/earnie-$1/.env" "$release/earnie-$1/tenant.env"
  echo "$1" > "$release/earnie-$1/VERSION"
}
new_bundle v9.9.9
bundle=$release/earnie-v9.9.9
env_file=$bundle/tenant.env
read_var() { sed -n "s/^$1=//p" "$env_file" | tail -1; }
env_var() { sed -n "s/^$1=//p" "$bundle/.env" | tail -1; }
fail() { echo "FAIL: $*" >&2; exit 1; }
expect_fail() { # message-fragment, then the command
  local fragment=$1; shift
  local out
  if out=$("$@" 2>&1 </dev/null); then fail "expected a refusal mentioning '$fragment', got success:"$'\n'"$out"; fi
  grep -qF -- "$fragment" <<<"$out" || fail "expected '$fragment' in:"$'\n'"$out"
}
required=(EARNIE_HOST=earnie.acme.com SCANOSS_API_KEY=key-1 EARNIE_INITIAL_ADMIN_EMAIL=admin@acme.com EARNIE_ORG_NAME=Acme)

# ---- preflight ----
FAKE_DOCKER_VERSION=28.3.1 expect_fail "Docker Engine 29 or later" "$bundle/install.sh"
FAKE_INFO_RC=1 expect_fail "docker group" "$bundle/install.sh"
[ ! -f "$env_file" ] || fail "preflight runs before tenant.env is created"
(export "${required[@]}" FAKE_FREE_KB=5000000; expect_fail "under 10 GiB free" "$bundle/install.sh")
rm -f "$env_file"
echo "preflight: ok"

# ---- a first run without a terminal names what it needs and writes nothing ----
expect_fail "tenant.env needs: EARNIE_HOST SCANOSS_API_KEY EARNIE_INITIAL_ADMIN_EMAIL EARNIE_ORG_NAME" "$bundle/install.sh"
[ -f "$env_file" ] || fail "the first run creates tenant.env"
[ "$(stat -c %a "$env_file")" = 600 ] || fail "tenant.env must be 0600"
cmp -s "$env_file" "$bundle/tenant.env.example" || fail "a refused run must leave tenant.env as the example"
EARNIE_HOST=earnie.acme.com SCANOSS_API_KEY=k expect_fail "tenant.env needs: EARNIE_INITIAL_ADMIN_EMAIL EARNIE_ORG_NAME" "$bundle/install.sh"
cmp -s "$env_file" "$bundle/tenant.env.example" || fail "a refused run must not keep the answers it did get"
(export "${required[@]}" EARNIE_INITIAL_ADMIN_PASSWORD=short; expect_fail "12 to 128 characters" "$bundle/install.sh")
cmp -s "$env_file" "$bundle/tenant.env.example" || fail "a refused password must not be written"
(export "${required[@]}" EARNIE_HOST=https://earnie.acme.com/; expect_fail "a bare DNS name" "$bundle/install.sh")
(export "${required[@]}" EARNIE_MODULES=oss,cyrpto; expect_fail "'cyrpto' is not a module" "$bundle/install.sh")
(export "${required[@]}" DB_URL=mysql://x; expect_fail "DB_URL: postgres://user:password@host:5432/db" "$bundle/install.sh")
(export "${required[@]}" DB_URL=postgres://e:p@localhost:5432/e; expect_fail "localhost inside a container" "$bundle/install.sh")
(export "${required[@]}" EARNIE_ORG_NAME='"Acme"'; expect_fail "cannot start with a quote" "$bundle/install.sh")
(export "${required[@]}" EARNIE_INITIAL_ADMIN_PASSWORD='long enough #1 pw'; expect_fail "cannot contain ' #'" "$bundle/install.sh")
(export "${required[@]}" EARNIE_INITIAL_ADMIN_EMAIL=admin@corp.lan; expect_fail "Let's Encrypt refuses a contact" "$bundle/install.sh")
cmp -s "$env_file" "$bundle/tenant.env.example" || fail "a refused value must not be written"
(export "${required[@]}" EARNIE_INITIAL_ADMIN_EMAIL=admin@corp.lan EARNIE_ACME_EMAIL=ops@acme.com; "$bundle/install.sh" </dev/null >/dev/null 2>&1 || fail "an internal admin email is fine when EARNIE_ACME_EMAIL is set")
rm -f "$env_file" "$bundle/.env"
echo "missing values: ok"

# ---- first run from the environment: derives, generates, pulls, starts ----
: > "$FAKE_PRESENT"; : > "$FAKE_LOG"
out=$(env "${required[@]}" EARNIE_DATA_DIR=$work/data1 "$bundle/install.sh" </dev/null 2>&1) || fail "first run failed:"$'\n'"$out"
grep -q "from the environment: EARNIE_HOST SCANOSS_API_KEY EARNIE_INITIAL_ADMIN_EMAIL EARNIE_ORG_NAME EARNIE_DATA_DIR" <<<"$out" || fail "the keys taken from the environment are named:"$'\n'"$out"
if grep -q "key-1" <<<"$out"; then fail "a secret from the environment must not be printed"; fi
grep -q "DB_URL is empty: running the bundled postgres on $work/data1/postgres" <<<"$out" || fail "the bundled postgres is announced:"$'\n'"$out"
[ "$(read_var EARNIE_DATA_DIR)" = "$work/data1" ] || fail "an exported EARNIE_DATA_DIR is written on the first run"
[ "$(env_var WORKER_CRYPTO_CPUS)" = 4 ] && [ "$(env_var WORKER_AI_CPUS)" = 4 ] || fail "worker cores default to 4 on an 8-core host"
[ "$(read_var EARNIE_HOST)" = earnie.acme.com ] || fail "EARNIE_HOST not written"
[ "$(read_var SCANOSS_API_KEY)" = key-1 ] || fail "SCANOSS_API_KEY not written"
[ "$(read_var EARNIE_ORG_NAME)" = Acme ] || fail "EARNIE_ORG_NAME not written"
[ "$(read_var EARNIE_MODULES)" = oss,enrichment ] || fail "EARNIE_MODULES defaults to oss,enrichment"
[ "$(read_var EARNIE_PASSWORD_AUTH_ENABLED)" = true ] || fail "password sign-in must be on without OIDC"
password=$(read_var EARNIE_INITIAL_ADMIN_PASSWORD)
grep -qE '^[0-9a-f]{24}$' <<<"$password" || fail "the admin password must be generated, got '$password'"
grep -q "sign in at https://earnie.acme.com as admin@acme.com with the password $password" <<<"$out" || fail "the last line names the sign-in URL, user and generated password:"$'\n'"$out"
[ -z "$(read_var EARNIE_TLS)" ] && [ "$(env_var EARNIE_TLS)" = acme ] || fail "no certificate files means acme, derived into .env only"
[ -z "$(read_var EARNIE_ONPREM_POSTGRES)" ] && [ "$(env_var EARNIE_ONPREM_POSTGRES)" = true ] || fail "an empty DB_URL means the bundled postgres, derived into .env only"
pg_password=$(read_var ONPREM_PG_PASSWORD)
grep -qE '^[0-9a-f]{64}$' <<<"$pg_password" || fail "ONPREM_PG_PASSWORD must be generated"
[ "$(read_var DB_URL)" = "postgres://earnie:$pg_password@postgres:5432/earnie" ] || fail "DB_URL must carry the generated password, got $(read_var DB_URL)"
grep -q "COMPOSE_PROFILES=onprem" "$bundle/.env" || fail "the bundled postgres needs the onprem profile"
for key in JWT_SECRET EARNIE_SSO_KEK_HEX EARNIE_INTEGRATIONS_KEK_HEX; do
  grep -qE '^[0-9a-f]{64}$' <<<"$(read_var "$key")" || fail "$key must be generated as 64 hex characters"
done
[ "$(read_var JWT_SECRET)" != "$(read_var EARNIE_SSO_KEK_HEX)" ] || fail "secrets must differ"
[ -z "$(read_var EARNIE_VERSION)" ] || fail "EARNIE_VERSION stays empty in tenant.env so a new bundle needs no edit"
[ "$(env_var EARNIE_VERSION)" = v9.9.9 ] || fail ".env must take the version from the bundle's VERSION file"
[ "$(env_var EARNIE_ACME_EMAIL)" = admin@acme.com ] || fail "the ACME contact derives from the admin email"
[ "$(env_var DOCKER_GID)" = 988 ] || fail "DOCKER_GID must come from the docker group, got $(env_var DOCKER_GID)"
[ "$(env_var DOCKER_BRIDGE_IP)" = 172.18.0.1 ] || fail "DOCKER_BRIDGE_IP must come from the bridge network, got $(env_var DOCKER_BRIDGE_IP)"
[ "$(env_var SANDBOX_CPUS)" = 8 ] || fail "SANDBOX_CPUS must follow the host's cores, got $(env_var SANDBOX_CPUS)"
[ "$(env_var DOCKER_CLI)" = "$FAKE/docker" ] || fail "DOCKER_CLI must be the docker on PATH, got $(env_var DOCKER_CLI)"
grep -q -- "-k --noproxy \* --max-time 10 -o /dev/null --resolve earnie.acme.com:443:127.0.0.1 https://earnie.acme.com/healthz" "$FAKE_LOG" || fail "the HTTPS probe must resolve the host to this machine, without a proxy"
grep -q "pulling images" <<<"$out" && grep -qx "compose pull" "$FAKE_LOG" || fail "without an archive the images are pulled:"$'\n'"$out"
if grep -q "^manifest inspect" "$FAKE_LOG"; then fail "the ai image is only checked when ai is chosen"; fi
echo "first run: ok"

# ---- a second run changes nothing, asks nothing, pulls nothing ----
cp "$env_file" "$work/tenant.env.before"
: > "$FAKE_LOG"
out=$("$bundle/install.sh" 2>&1 </dev/null) || fail "second run failed:"$'\n'"$out"
cmp -s "$env_file" "$work/tenant.env.before" || fail "a second run must leave tenant.env untouched"
if grep -qE "^(load |compose pull)" "$FAKE_LOG"; then fail "a second run must not pull or load images that are present"; fi
if grep -q "DockerRootDir" "$FAKE_LOG"; then fail "docker's disk is only checked when images are to be fetched"; fi
grep -q "images for v9.9.9 present" <<<"$out" || fail "second run must say the images are present"
if grep -q "$password" <<<"$out"; then fail "a second run must not print the password again"; fi
grep -q "with the password in tenant.env" <<<"$out" && grep -q "clear it once you have signed in" <<<"$out" || fail "a run with the password still set must say where it is and that it is set again:"$'\n'"$out"
# The admin password may be cleared after the first sign-in; a run on a terminal must not ask for it again.
sed -i 's/^EARNIE_INITIAL_ADMIN_PASSWORD=.*/EARNIE_INITIAL_ADMIN_PASSWORD=/' "$env_file"
python3 - "$bundle/install.sh" <<'PY' || fail "a run with the password cleared must not prompt"
import os, pty, sys
pid, fd = pty.fork()
if pid == 0:
    os.execv(sys.argv[1], [sys.argv[1]])
out = b""
while True:
    try: chunk = os.read(fd, 4096)
    except OSError: break
    if not chunk: break
    out += chunk
    if out.rstrip().endswith(b":"): os.kill(pid, 9); print("PROMPTED: " + out.decode(errors="replace")); sys.exit(1)
_, status = os.waitpid(pid, 0)
sys.exit(0 if os.WIFEXITED(status) and os.WEXITSTATUS(status) == 0 else 1)
PY
echo "second run: ok"

# ---- an upgrade: the next bundle takes tenant.env from the previous one ----
new_bundle v9.9.10
out=$("$release/earnie-v9.9.10/install.sh" 2>&1 </dev/null) || fail "upgrade run failed:"$'\n'"$out"
grep -q "took tenant.env from ../earnie-v9.9.9" <<<"$out" || fail "the upgrade must say where tenant.env came from"
cmp -s "$release/earnie-v9.9.10/tenant.env" "$env_file" || fail "the upgrade must carry tenant.env over unchanged"
grep -qx "EARNIE_VERSION=v9.9.10" "$release/earnie-v9.9.10/.env" || fail "the new bundle runs its own release"
rm -rf "$release/earnie-v9.9.10"
# A key the next release adds is appended at its default; an old file without a final newline is not mangled.
new_bundle v9.9.11
printf '# A knob this release adds.\nEARNIE_NEW_KNOB=7\n' >> "$release/earnie-v9.9.11/tenant.env.example"
printf '%s' "$(cat "$env_file")" > "$env_file"
out=$("$release/earnie-v9.9.11/install.sh" 2>&1 </dev/null) || fail "upgrade with a new key failed:"$'\n'"$out"
grep -qx "EARNIE_NEW_KNOB=7" "$release/earnie-v9.9.11/tenant.env" || fail "a key the new release adds must be appended at its default"
[ "$(grep -c '^EARNIE_HOST=' "$release/earnie-v9.9.11/tenant.env")" = 1 ] && grep -qx "EARNIE_HOST=earnie.acme.com" "$release/earnie-v9.9.11/tenant.env" || fail "existing keys must stay single and intact"
rm -rf "$release/earnie-v9.9.11"
# A running installation names its bundle directory: tenant.env comes from there, wherever the new bundle is.
mkdir -p "$work/elsewhere"; new_bundle v9.9.12; mv "$release/earnie-v9.9.12" "$work/elsewhere/"
out=$(FAKE_INSTALLED=$bundle "$work/elsewhere/earnie-v9.9.12/install.sh" 2>&1 </dev/null) || fail "upgrade from the installed directory failed:"$'\n'"$out"
grep -q "took tenant.env from $bundle" <<<"$out" || fail "the upgrade must take tenant.env from the installed bundle directory:"$'\n'"$out"
rm -rf "$work/elsewhere"
new_bundle v9.9.13; mv "$release/earnie-v9.9.13" "$work/"
FAKE_INSTALLED=$work/gone expect_fail "Earnie is installed from $work/gone but its tenant.env is gone" "$work/earnie-v9.9.13/install.sh"
FAKE_INSTALLED=$work/earnie-v9.9.13 expect_fail "Earnie is installed from $work/earnie-v9.9.13 but its tenant.env is gone" "$work/earnie-v9.9.13/install.sh"
[ ! -f "$work/earnie-v9.9.13/tenant.env" ] || fail "a deleted tenant.env of the installed bundle must not be replaced by a sibling's"
rm -rf "$work/earnie-v9.9.13"
# An older bundle refuses to start on data a newer release migrated.
new_bundle v9.9.8; mv "$release/earnie-v9.9.8" "$work/"
FAKE_INSTALLED=$bundle expect_fail "Earnie v9.9.9 runs from $bundle and this bundle is v9.9.8, an older release" "$work/earnie-v9.9.8/install.sh"
[ ! -f "$work/earnie-v9.9.8/tenant.env" ] || fail "a downgrade must write nothing"
rm -rf "$work/earnie-v9.9.8"
# Without a previous bundle beside it, data of an installation refuses a fresh tenant.env.
mkdir -p "$work/alone/earnie-v9.9.9" "$work/data-old/postgres"
cp -r "$bundle/." "$work/alone/earnie-v9.9.9/"; rm -f "$work/alone/earnie-v9.9.9/tenant.env" "$work/alone/earnie-v9.9.9/.env"
sed -i "s|^EARNIE_DATA_DIR=.*|EARNIE_DATA_DIR=$work/data-old|" "$work/alone/earnie-v9.9.9/tenant.env.example"
expect_fail "holds the data of an Earnie installation but there is no tenant.env" "$work/alone/earnie-v9.9.9/install.sh"
[ ! -f "$work/alone/earnie-v9.9.9/tenant.env" ] || fail "no tenant.env may be created over an existing installation"
echo "upgrade: ok"

# ---- a prefilled tenant.env is used as is; nothing set is overridden ----
rm -f "$env_file" "$bundle/.env"
cp "$bundle/tenant.env.example" "$env_file"
sed -i 's|^EARNIE_HOST=.*|EARNIE_HOST=scan.corp.internal|; s|^SCANOSS_API_KEY=.*|SCANOSS_API_KEY=key-2|; s|^EARNIE_INITIAL_ADMIN_EMAIL=.*|EARNIE_INITIAL_ADMIN_EMAIL=ops@corp.internal|; s|^EARNIE_INITIAL_ADMIN_PASSWORD=.*|EARNIE_INITIAL_ADMIN_PASSWORD=a-long-enough-password|; s|^EARNIE_ORG_NAME=.*|EARNIE_ORG_NAME=Corp Inc|; s|^EARNIE_MODULES=.*|EARNIE_MODULES=oss,crypto|; s|^DB_URL=.*|DB_URL=postgres://earnie:pw@db.corp.internal:5432/earnie|; s|^JWT_SECRET=.*|JWT_SECRET=my-own-jwt-secret-of-32-chars-xx|; s|^DOCKER_GID=.*|DOCKER_GID=988|; s|^SANDBOX_CPUS=.*|SANDBOX_CPUS=6|; s|^EARNIE_VERSION=.*|EARNIE_VERSION=v9.9.9|; s|^EARNIE_DATA_DIR=.*|EARNIE_DATA_DIR='"$work"'/data|' "$env_file"
mkdir -p "$work/data/tls"; echo c > "$work/data/tls/cert.pem"; echo k > "$work/data/tls/key.pem"
cp "$env_file" "$work/tenant.env.prefilled"
out=$("$bundle/install.sh" 2>&1 </dev/null) || fail "prefilled run failed:"$'\n'"$out"
for key in EARNIE_HOST SCANOSS_API_KEY EARNIE_INITIAL_ADMIN_EMAIL EARNIE_INITIAL_ADMIN_PASSWORD EARNIE_ORG_NAME EARNIE_MODULES DB_URL JWT_SECRET DOCKER_GID SANDBOX_CPUS EARNIE_VERSION; do
  [ "$(read_var "$key")" = "$(sed -n "s/^$key=//p" "$work/tenant.env.prefilled" | tail -1)" ] || fail "$key was changed by install.sh"
done
[ "$(env_var EARNIE_ONPREM_POSTGRES)" = false ] || fail "a DB_URL of your own must not start the bundled postgres"
[ -z "$(read_var ONPREM_PG_PASSWORD)" ] || fail "no postgres password is generated for an external database"
[ "$(env_var EARNIE_TLS)" = custom ] || fail "both certificate files in place mean custom"
grep -q -- "--cacert $work/data/tls/cert.pem --noproxy" "$FAKE_LOG" || fail "a custom certificate is verified against its own file"
[ "$(env_var DOCKER_GID)" = 988 ] && [ "$(env_var SANDBOX_CPUS)" = 6 ] || fail "set host values must reach .env unchanged"
grep -q "COMPOSE_PROFILES=crypto" "$bundle/.env" || fail "crypto profile expected"
echo "prefilled tenant.env: ok"

# ---- a literal $ survives, and the last of duplicate keys is the one set ----
rm -f "$env_file" "$bundle/.env"
cp "$bundle/tenant.env.example" "$env_file"
printf 'EARNIE_ORG_NAME=\n' >> "$env_file"
sed -i '0,/^EARNIE_ORG_NAME=$/s//EARNIE_ORG_NAME=First/' "$env_file"
sed -i 's|^ONPREM_PG_PASSWORD=.*|ONPREM_PG_PASSWORD=pg$$p@w/1|; s|^ONPREM_PG_USER=.*|ONPREM_PG_USER=ea/rnie|' "$env_file"
out=$(env "${required[@]}" EARNIE_ORG_NAME=Second EARNIE_INITIAL_ADMIN_PASSWORD='pa$$word-of-length' "$bundle/install.sh" </dev/null 2>&1) || fail "dollar run failed:"$'\n'"$out"
grep -qx 'EARNIE_INITIAL_ADMIN_PASSWORD=pa$$$$word-of-length' "$env_file" || fail "a \$ must be written as \$\$ for compose, got $(read_var EARNIE_INITIAL_ADMIN_PASSWORD)"
grep -qx 'DB_URL=postgres://ea%2Frnie:pg%24p%40w%2F1@postgres:5432/earnie' "$env_file" || fail "the postgres password must be URL-encoded once and not escaped twice, got $(read_var DB_URL)"
[ "$(read_var EARNIE_ORG_NAME)" = Second ] || fail "the last EARNIE_ORG_NAME line must be the one set"
grep -qx 'EARNIE_ORG_NAME=First' "$env_file" || fail "an earlier set line must not be touched"
ln -sf "$env_file" "$work/link.env"; mv "$env_file" "$work/real.env"; ln -sf "$work/real.env" "$env_file"
sed -i 's|^EARNIE_ORG_NAME=.*|EARNIE_ORG_NAME=|' "$work/real.env"
env "${required[@]}" EARNIE_ORG_NAME=Third "$bundle/install.sh" </dev/null >/dev/null 2>&1 || fail "a symlinked tenant.env must work"
[ -L "$env_file" ] && grep -qx 'EARNIE_ORG_NAME=Third' "$work/real.env" || fail "a symlinked tenant.env must be written through, not replaced"
rm -f "$env_file" "$work/link.env"; mv "$work/real.env" "$env_file"
# A commented-out key is never re-enabled: the value goes on a new line.
sed -i 's|^EARNIE_ORG_NAME=.*|# EARNIE_ORG_NAME=|' "$env_file"
env "${required[@]}" EARNIE_ORG_NAME=Fourth "$bundle/install.sh" </dev/null >/dev/null 2>&1 || fail "a commented-out key must be filled on a new line"
grep -qx '# EARNIE_ORG_NAME=' "$env_file" && [ "$(read_var EARNIE_ORG_NAME)" = Fourth ] || fail "the commented-out line must stay and the value must be appended"
# A DB_URL from the environment counts like every other fill-in value.
sed -i 's|^DB_URL=.*|DB_URL=|' "$env_file"
DB_URL=postgres://e:p@db.example.com:5432/e "$bundle/install.sh" </dev/null >/dev/null 2>&1 || fail "an exported DB_URL must be accepted"
[ "$(read_var DB_URL)" = postgres://e:p@db.example.com:5432/e ] || fail "an exported DB_URL must be written, got $(read_var DB_URL)"
echo "dollar and duplicates: ok"

# ---- what render-env.sh refuses, with the fix in the message ----
sed -i 's|^EARNIE_MODULES=.*|EARNIE_MODULES=oss, crypto|' "$env_file"
expect_fail "comma-separated without spaces" "$bundle/render-env.sh"
sed -i 's|^EARNIE_MODULES=.*|EARNIE_MODULES=oss,cyrpto|' "$env_file"
expect_fail "EARNIE_MODULES has 'cyrpto'" "$bundle/render-env.sh"
sed -i 's|^EARNIE_MODULES=.*|EARNIE_MODULES=oss,|' "$env_file"
expect_fail "empty entries" "$bundle/render-env.sh"
sed -i 's|^EARNIE_MODULES=.*|EARNIE_MODULES=oss,crypto|; s|^DOCKER_GID=.*|DOCKER_GID=5000|' "$env_file"
expect_fail "DOCKER_GID=5000 but /var/run/docker.sock belongs to group 988" "$bundle/render-env.sh"
sed -i 's|^DOCKER_GID=.*|DOCKER_GID=|; s|^DOCKER_BRIDGE_IP=.*|DOCKER_BRIDGE_IP=172.17.0.1|' "$env_file"
expect_fail "DOCKER_BRIDGE_IP=172.17.0.1 but this host's docker bridge is 172.18.0.1" "$bundle/render-env.sh"
sed -i 's|^DOCKER_BRIDGE_IP=.*|DOCKER_BRIDGE_IP=|' "$env_file"
sed -i 's|^EARNIE_MODULES=.*|EARNIE_MODULES=oss,crypto|; s|^SANDBOX_CPUS=.*|SANDBOX_CPUS=14|' "$env_file"
expect_fail "SANDBOX_CPUS=14 but this host has 8 CPUs" "$bundle/render-env.sh"
sed -i 's|^SANDBOX_CPUS=.*|SANDBOX_CPUS=|; s|^WORKER_CRYPTO_CPUS=.*|WORKER_CRYPTO_CPUS=16|' "$env_file"
expect_fail "WORKER_CRYPTO_CPUS=16 but this host has 8 CPUs" "$bundle/render-env.sh"
sed -i 's|^WORKER_CRYPTO_CPUS=.*|WORKER_CRYPTO_CPUS=4|; s|^SANDBOX_MEMORY=.*|SANDBOX_MEMORY=4096Gi|' "$env_file"
expect_fail "crypto needs SANDBOX_MEMORY (4096Gi) plus WORKER_CRYPTO_MEM_LIMIT (8g)" "$bundle/render-env.sh"
sed -i 's|^SANDBOX_MEMORY=.*|SANDBOX_MEMORY=12Gi|; s|^EARNIE_VERSION=.*|EARNIE_VERSION=v1.0.0|' "$env_file"
expect_fail "EARNIE_VERSION=v1.0.0 but this bundle is v9.9.9" "$bundle/render-env.sh"
sed -i 's|^EARNIE_VERSION=.*|EARNIE_VERSION=|; s|^EARNIE_SSO_KEK_HEX=.*|EARNIE_SSO_KEK_HEX=abc|' "$env_file"
expect_fail "EARNIE_SSO_KEK_HEX must be exactly 64 hex characters" "$bundle/render-env.sh"
sed -i "s|^EARNIE_SSO_KEK_HEX=.*|EARNIE_SSO_KEK_HEX=$(printf '0%.0s' $(seq 1 64))|; s|^EARNIE_PASSWORD_AUTH_ENABLED=.*|EARNIE_PASSWORD_AUTH_ENABLED=false|" "$env_file"
expect_fail "nobody could sign in" "$bundle/render-env.sh"
sed -i 's|^EARNIE_PASSWORD_AUTH_ENABLED=.*|EARNIE_PASSWORD_AUTH_ENABLED=true|; s|^OIDC_ISSUER=.*|OIDC_ISSUER=https://idp.example.com|' "$env_file"
expect_fail "OIDC_ISSUER, OIDC_CLIENT_ID and OIDC_CLIENT_SECRET go together" "$bundle/render-env.sh"
sed -i 's|^OIDC_ISSUER=.*|OIDC_ISSUER=|; s|^DB_URL=.*|DB_URL=postgres://earnie:pw@localhost:5432/earnie|' "$env_file"
expect_fail "DB_URL points at localhost" "$bundle/render-env.sh"
sed -i 's|^DB_URL=.*|DB_URL=postgres://earnie:pw@db.example.com:5432/earnie|; s|^EARNIE_HOST=.*|EARNIE_HOST=https://earnie.acme.com/|' "$env_file"
expect_fail "EARNIE_HOST must be a bare DNS name" "$bundle/render-env.sh"
sed -i 's|^EARNIE_HOST=.*|EARNIE_HOST=earnie.acme.com|' "$env_file"
"$bundle/render-env.sh" >/dev/null || fail "render-env.sh must accept the repaired tenant.env"
echo "refusals: ok"

# ---- the archive: loaded only when named, checked against the release's .sha256 ----
: > "$FAKE_PRESENT"; : > "$FAKE_LOG"
archive=$release/earnie-onprem-images-v9.9.9.tar.zst
: > "$archive"
(cd "$release" && sha256sum earnie-onprem-images-v9.9.9.tar.zst > earnie-onprem-images-v9.9.9.sha256)
out=$(cd "$release" && earnie-v9.9.9/install.sh earnie-onprem-images-v9.9.9.tar.zst 2>&1 </dev/null) || fail "an archive named from the download directory must load:"$'\n'"$out"
grep -q "checking $release/earnie-onprem-images-v9.9.9.sha256" <<<"$out" || fail "the release checksums are checked before the load:"$'\n'"$out"
grep -qx "load -i $archive" "$FAKE_LOG" || fail "the archive argument must be resolved before the script changes directory"
if grep -qx "compose pull" "$FAKE_LOG"; then fail "an archive run must not pull"; fi
# A damaged download is refused before the load.
: > "$FAKE_PRESENT"
echo "0000000000000000000000000000000000000000000000000000000000000000  earnie-onprem-images-v9.9.9.tar.zst" > "$release/earnie-onprem-images-v9.9.9.sha256"
expect_fail "a release file is damaged or incomplete" "$bundle/install.sh" "$archive"
rm -f "$release/earnie-onprem-images-v9.9.9.sha256"
"$bundle/install.sh" "$archive" </dev/null >/dev/null 2>&1 || fail "the load without a checksum file must still work"
expect_fail "no such file" "$bundle/install.sh" "$release/missing.tar.zst"
# Without the registry, a plain run points at the archive path; the sibling archive is never picked up by itself.
: > "$FAKE_PRESENT"; : > "$FAKE_LOG"
FAKE_PULL_RC=1 expect_fail "get earnie-onprem-images-v9.9.9.tar.zst from SCANOSS's SFTP and run ./install.sh <archive>" "$bundle/install.sh"
if grep -q "^load " "$FAKE_LOG"; then fail "an archive beside the bundle must not be loaded unless named"; fi
rm -f "$archive"
echo "archive: ok"

# ---- a certificate Caddy could not get is not a success; an unhealthy service shows its log ----
FAKE_CURL_RC=22 expect_fail "the api or the database is not ready, see docker compose logs earnie-api postgres" "$bundle/install.sh"
: > "$FAKE_LOG"
FAKE_UP_RC=1 expect_fail "--- caddy: Up 5 seconds (unhealthy)" "$bundle/install.sh"
grep -q "compose logs --no-log-prefix --tail=15 caddy" "$FAKE_LOG" && grep -q "tail=15 bootstrap" "$FAKE_LOG" || fail "the unhealthy and the failed service's logs must be shown"
if grep -qE "tail=15 (web|worker-crypto|migrate)" "$FAKE_LOG"; then fail "a healthy service, or one without a healthcheck, must not be dumped"; fi
FAKE_CURL_RC=60 expect_fail "no usable certificate: Caddy could not get one from Let's Encrypt yet, for earnie.acme.com with the contact admin@acme.com" "$bundle/install.sh"
FAKE_CURL_RC=7 expect_fail "does not answer (curl exit 7)" "$bundle/install.sh"
echo "https probe: ok"
# ---- ai: refused before tenant.env is written when its image is not to be had ----
no_ai="AI provenance isn't available for self-hosted installs yet; choose modules without ai"
: > "$FAKE_PRESENT"; : > "$FAKE_LOG"
: > "$archive"
printf '%s\n' ghcr.io/scanoss/earnie/earnie-api:v9.9.9 ghcr.io/scanoss/earnie/earnie-web:v9.9.9 caddy:2-alpine > "$release/earnie-onprem-images-v9.9.9.images.txt"
sed -i 's|"compose config --images") printf|"compose config --images") [ -z "${FAKE_AI:-}" ] \|\| echo ghcr.io/scanoss/earnie/earnie-api-ai:v9.9.9; printf|' "$FAKE/docker"
# The list beside the archive refuses the image before the long load.
FAKE_AI=1 expect_fail "$no_ai" "$bundle/install.sh" "$archive"
if grep -q "^load " "$FAKE_LOG"; then fail "the archive must not be loaded when it lacks an image"; fi
cp "$env_file" "$work/tenant.env.keep"; rm -f "$env_file"
(export "${required[@]}" EARNIE_MODULES=oss,ai; expect_fail "$no_ai" "$bundle/install.sh" "$archive")
cmp -s "$env_file" "$bundle/tenant.env.example" || fail "a refused ai must not be written"
# Pulling: the registry is asked for the ai image before anything is written.
: > "$FAKE_LOG"
(export "${required[@]}" EARNIE_MODULES=oss,ai; FAKE_MANIFEST_RC=1 expect_fail "$no_ai" "$bundle/install.sh")
grep -qx "manifest inspect ghcr.io/scanoss/earnie/earnie-api-ai:v9.9.9" "$FAKE_LOG" || fail "the ai image must be checked against the registry"
cmp -s "$env_file" "$bundle/tenant.env.example" || fail "a refused ai must not be written"
(export "${required[@]}" EARNIE_MODULES=oss,ai; FAKE_MANIFEST_RC=0 "$bundle/install.sh" </dev/null >/dev/null 2>&1) || fail "ai must be accepted when the registry serves its image"
[ "$(read_var EARNIE_MODULES)" = oss,ai,enrichment ] || fail "ai is written when its image is available, enrichment added"
# A set EARNIE_MODULES is never changed, even when the image is gone.
FAKE_MANIFEST_RC=1 expect_fail "$no_ai" "$bundle/install.sh"
[ "$(read_var EARNIE_MODULES)" = oss,ai,enrichment ] || fail "a set EARNIE_MODULES must not be overridden"
cp "$work/tenant.env.keep" "$env_file"
rm -f "$release/earnie-onprem-images-v9.9.9.images.txt" "$archive"
echo "ai availability: ok"

# ---- the interactive first run: every answer lands, secrets are not echoed ----
rm -f "$env_file" "$bundle/.env"
python3 - "$bundle/install.sh" <<'PY' || fail "interactive run failed"
import os, pty, sys
answers = {
    "DNS name users will type (such as earnie.example.com)": b"earnie.example.org\n",
    "SCANOSS API key": b"key-interactive\n",
    "Administrator email": b"\n",
    "required": b"root@acme.test\n",
    "Administrator password": b"twelve-chars-min\n",
    "Organisation name (cannot be changed later) [Example]": b"\n",
    "Scanners bought": b"oss, cyrpto\n",
    "'cyrpto' is not a module": b"oss, crypto\n",
}
pid, fd = pty.fork()
if pid == 0:
    os.execv(sys.argv[1], [sys.argv[1]])
out = b""; seen = set()
while True:
    try: chunk = os.read(fd, 4096)
    except OSError: break
    if not chunk: break
    out += chunk
    for key, answer in answers.items():
        if key in seen: continue
        tail = out[-400:].decode(errors="replace")
        if key in tail and tail.rstrip().endswith(":"):
            seen.add(key); os.write(fd, answer); break
_, status = os.waitpid(pid, 0)
text = out.decode(errors="replace")
if os.WEXITSTATUS(status) != 0: print(text); sys.exit(1)
if len(seen) != len(answers): print("not every question was asked: " + str(sorted(set(answers) - seen))); print(text); sys.exit(1)
if "key-interactive" in text or "twelve-chars-min" in text: print("a secret was echoed"); sys.exit(1)
print(text.splitlines()[-1])
PY
[ "$(read_var EARNIE_HOST)" = earnie.example.org ] || fail "interactive EARNIE_HOST"
[ "$(read_var SCANOSS_API_KEY)" = key-interactive ] || fail "interactive SCANOSS_API_KEY"
[ "$(read_var EARNIE_INITIAL_ADMIN_PASSWORD)" = twelve-chars-min ] || fail "interactive password"
[ "$(read_var EARNIE_ORG_NAME)" = Example ] || fail "interactive org default"
[ "$(read_var EARNIE_MODULES)" = oss,crypto,enrichment ] || fail "interactive modules: spaces stripped, enrichment always on, got '$(read_var EARNIE_MODULES)'"
[ "$(env_var EARNIE_ONPREM_POSTGRES)" = true ] || fail "interactive bundled postgres"
echo "interactive first run: ok"

# ---- Enter on the password question generates one, printed once at the end ----
rm -f "$env_file" "$bundle/.env"
ENV_FILE="$env_file" FAKE_MANIFEST_RC=0 python3 - "$bundle/install.sh" <<'PY' || fail "interactive run with a generated password failed"
import os, pty, re, sys
answers = {
    "DNS name users will type (such as earnie.example.com)": b"earnie.example.org\n",
    "SCANOSS API key": b"key-interactive\n",
    "Administrator email": b"root@acme.test\n",
    "Administrator password": b"\n",
    "Organisation name (cannot be changed later) [Example]": b"\n",
    "Scanners bought": b"\n",
}
pid, fd = pty.fork()
if pid == 0:
    os.execv(sys.argv[1], [sys.argv[1]])
out = b""; seen = set()
while True:
    try: chunk = os.read(fd, 4096)
    except OSError: break
    if not chunk: break
    out += chunk
    for key, answer in answers.items():
        if key in seen: continue
        tail = out[-400:].decode(errors="replace")
        if key in tail and tail.rstrip().endswith(":"):
            seen.add(key); os.write(fd, answer); break
_, status = os.waitpid(pid, 0)
text = out.decode(errors="replace")
if os.WEXITSTATUS(status) != 0: print(text); sys.exit(1)
if text.count("Administrator password") != 1: print("the password question must be asked once, Enter generates one"); print(text); sys.exit(1)
if "Scanners bought, comma-separated: oss,crypto,ai" not in text: print("ai must be offered when the registry serves its image"); print(text); sys.exit(1)
env = open(os.environ["ENV_FILE"]).read()
m = re.search(r"^EARNIE_INITIAL_ADMIN_PASSWORD=([0-9a-f]{24})$", env, re.M)
if not m: print("no generated 24-hex password in tenant.env"); print(env); sys.exit(1)
if text.count(m.group(1)) != 1: print("the generated password must be printed exactly once"); print(text); sys.exit(1)
PY
[ "$(read_var EARNIE_MODULES)" = oss,enrichment ] || fail "Enter on scanners means oss plus enrichment, got '$(read_var EARNIE_MODULES)'"
echo "generated password on Enter, ai offered when served: ok"

for script in "$bundle"/*.sh; do bash -n "$script"; done
echo "install: ok"
