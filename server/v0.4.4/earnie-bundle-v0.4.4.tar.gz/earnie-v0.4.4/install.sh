#!/usr/bin/env bash
# Install or upgrade an Earnie tenant on this host.
#
#   ./install.sh                 pull images from the registry and start
#   ./install.sh images.tar.zst  load an offline image archive first (on-prem);
#                                .tar.gz archives of older releases load too
#
# Expects tenant.env next to this script (copy tenant.env.example and fill it),
# Docker Engine 23 or later with the compose plugin, and the data directory from
# EARNIE_DATA_DIR (default /var/lib/earnie) on the volume you want to keep.
set -euo pipefail
cd "$(dirname "$0")"

command -v docker >/dev/null || { echo "docker is required" >&2; exit 1; }
docker compose version >/dev/null 2>&1 || { echo "the docker compose plugin is required" >&2; exit 1; }
[ -f tenant.env ] || { echo "tenant.env not found: cp tenant.env.example tenant.env and fill it in" >&2; exit 1; }
chmod 600 tenant.env

./render-env.sh
read_var() { sed -n "s/^$1=//p" tenant.env | head -1; }
EARNIE_TENANT=$(read_var EARNIE_TENANT)
EARNIE_HOST=$(read_var EARNIE_HOST)
EARNIE_DATA_DIR=$(read_var EARNIE_DATA_DIR)
[ -n "$EARNIE_HOST" ] || { echo "EARNIE_HOST is required" >&2; exit 1; }

if [ "${1:-}" != "" ]; then
  echo "==> loading images from $1"
  docker load -i "$1"
else
  echo "==> pulling images"
  docker compose pull
fi

mkdir -p "${EARNIE_DATA_DIR:-/var/lib/earnie}"
echo "==> starting tenant ${EARNIE_TENANT:-earnie} at https://${EARNIE_HOST}"
docker compose up -d --remove-orphans --wait
echo "==> healthy: https://${EARNIE_HOST}/healthz"
