#!/usr/bin/env bash
# Render the project .env that docker compose reads on its own, so a plain
# `docker compose up` in this directory is always correct.
set -euo pipefail
cd "$(dirname "$0")"
[ -f tenant.env ] || { echo "tenant.env not found: cp tenant.env.example tenant.env and fill it in" >&2; exit 1; }

queued_modules="crypto ai"

read_var() { sed -n "s/^$1=//p" tenant.env | head -1; }
modules=$(read_var EARNIE_MODULES)
onprem=$(read_var EARNIE_ONPREM_POSTGRES)
otlp_endpoint=$(read_var EARNIE_OTLP_ENDPOINT)

# Caddy pastes SCANS_MAX_UPLOAD_MB into its body cap as text, and the api
# refuses to start on a value it cannot read, so both see only this format.
for knob in SCANS_MAX_UPLOAD_MB SCANS_MAX_SBOM_MB SCANS_UPLOAD_TIMEOUT_SECONDS; do
  value=$(read_var "$knob")
  if [ -n "$value" ] && ! printf '%s' "$value" | grep -qE '^[1-9][0-9]{0,6}$'; then
    echo "$knob must be empty or a whole number from 1 to 9999999, got '$value'" >&2
    exit 1
  fi
done

# Caddy imports the snippet tls_<EARNIE_TLS>, so a typo would only surface as
# a crash loop behind --wait. Refuse it here, with the files each mode reads.
tls_mode=$(read_var EARNIE_TLS)
case "${tls_mode:-acme}" in
  acme)
    [ -n "$(read_var EARNIE_ACME_EMAIL)" ] || { echo "EARNIE_ACME_EMAIL is required with EARNIE_TLS=acme, the ACME account contact" >&2; exit 1; }
    ;;
  custom)
    data_dir=$(read_var EARNIE_DATA_DIR)
    tls_dir=$(read_var EARNIE_TLS_DIR)
    tls_dir=${tls_dir:-${data_dir:-/var/lib/earnie}/tls}
    for file in cert.pem key.pem; do
      [ -s "$tls_dir/$file" ] || { echo "EARNIE_TLS=custom needs $tls_dir/$file: the full certificate chain in cert.pem, its unencrypted key in key.pem" >&2; exit 1; }
    done
    ;;
  *)
    echo "EARNIE_TLS must be acme or custom, got '$tls_mode'" >&2
    exit 1
    ;;
esac

profiles=""
derived="COMPOSE_PROFILES|COMPOSE_FILE|EARNIE_TELEMETRY_SCRAPE_TARGETS"
scrape_targets='"earnie-api:8080"'
queued_env=""
summary=""
for module in $queued_modules; do
  queued=false
  case ",${modules}," in
    *,"$module",*) queued=true; profiles="${profiles:+$profiles,}$module"; scrape_targets="$scrape_targets,\"worker-$module:9090\"" ;;
  esac
  var="SCANS_$(printf '%s' "$module" | tr '[:lower:]' '[:upper:]')_QUEUED"
  derived="$derived|$var"
  queued_env="$queued_env$var=$queued"$'\n'
  summary="$summary ${module}_queued=$queued"
done
if [ "${onprem:-false}" = "true" ]; then
  [ -n "$(read_var ONPREM_PG_PASSWORD)" ] || { echo "ONPREM_PG_PASSWORD is required with EARNIE_ONPREM_POSTGRES=true" >&2; exit 1; }
  profiles="${profiles:+$profiles,}onprem"
fi
compose_file="compose.yaml"
if [ -n "$otlp_endpoint" ]; then
  profiles="${profiles:+$profiles,}telemetry"
  compose_file="compose.yaml:compose.logs.yaml"
fi

umask 077
{
  grep -vE "^($derived)=" tenant.env
  echo "COMPOSE_PROFILES=${profiles}"
  echo "COMPOSE_FILE=${compose_file}"
  echo "EARNIE_TELEMETRY_SCRAPE_TARGETS=[${scrape_targets}]"
  printf '%s' "$queued_env"
} > .env.tmp
mv .env.tmp .env
echo "rendered .env: profiles=${profiles:-none} files=${compose_file}${summary}"
