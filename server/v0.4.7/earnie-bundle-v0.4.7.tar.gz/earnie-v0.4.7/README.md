# Earnie tenant bundle

One tenant is one host running this directory with docker compose. The same
files serve a SCANOSS-managed VM and a customer's own machine (ADR 0081).

## Files

| File | Role |
|---|---|
| `compose.yaml` | caddy, web, api, migrate and bootstrap one-shots; `crypto`, `ai`, `onprem` and `telemetry` profiles |
| `otel-collector.yaml` | the `telemetry` profile's collector: api, worker and host metrics and every service's logs, exported over OTLP/HTTP |
| `compose.proxy.yaml` | override `render-env.sh` adds with `EARNIE_TLS=proxy`: Caddy serves plain http on `127.0.0.1:CADDY_HTTP_PORT` behind the host's TLS proxy |
| `compose.logs.yaml` | override `render-env.sh` adds to `COMPOSE_FILE` with telemetry: every service logs through Docker's `fluentd` driver to the collector |
| `Caddyfile` | TLS for `EARNIE_HOST` (ACME, or the operator's certificate with `EARNIE_TLS=custom`), the reverse proxy to web, and the headers that deny framing |
| `tenant.env.example` | every setting with its default: a short "fill in" block, then what `install.sh` generates or derives when empty, then the defaults |
| `render-env.sh` | checks `tenant.env` and writes the project `.env` from it: profiles and each queued scanner's switch from `EARNIE_MODULES`, the release from the bundle's `VERSION` file, the docker group id, the bridge address and the sandbox cores from the host |
| `bootstrap.sh` | converges organization, module toggles and the first admin; safe to rerun |
| `install.sh` | install or upgrade on a host: checks Docker, completes `tenant.env`, pulls the images (or loads the archive it is given), starts |
| `VERSION` | the release, only in a release bundle (`tools/release/onprem-archive.sh` adds it) |
| `images.sh` | prints every image the bundle can start for a release; the on-prem archive holds exactly these |
| `sandbox-egress.sh` | the `sandbox-egress` service: confines the dependency sandbox's subnet on the host firewall |
| `sandbox-registries.txt` | the public registry ranges a confined build may reach; `make sandbox-registries` regenerates it |
| `tests/compose_contract_test.sh` | the invariants below, run by `make test-compose` |
| `tests/install_test.sh` | `install.sh` and `render-env.sh` against a fake docker: preflight, derivation, generation, idempotency, the interactive first run |
| `tests/sandbox_egress_live_test.sh` | proves the egress rules on a real host, run by `make test-sandbox-egress-live` |

## Invariants

- The api never mounts the Docker socket. Only `worker-crypto` does, with the
  host's `docker` group, and it is the only service that receives
  `SCANS_CRYPTO_FINDER_PATH`.
- `worker-ai` runs the `earnie-api-ai` image, which adds Python and a pinned
  ai-finder-pro at `/opt/ai-finder/bin/ai-finder-pro`. It has no Docker
  socket and is the only service that receives `SCANS_AI_FINDER_PATH`. Its
  `/tmp` is `EARNIE_DATA_DIR/ai-scratch`, not a tmpfs (ADR 0082).
- `earnie-api` and `worker-ai` share `EARNIE_DATA_DIR/models` at
  `/var/lib/earnie/models` (`SCANS_MODELS_DIR`): uploaded Models, their
  uploads in flight and the trees staged for their scans (#1138). One mount,
  because a Model is stored and staged with hardlinks.
- The api port is published on the docker bridge address only
  (`DOCKER_BRIDGE_IP`), so sandbox containers reach the staging endpoint and
  the public interface exposes nothing but caddy.
- The api trusts `X-Forwarded-For` only from `web` (`EARNIE_TRUSTED_PROXIES`),
  so its rate limits and audit events see the browser's or the CLI's address.
  Caddy replaces any client-sent `X-Forwarded-For` with the address it saw,
  and Next.js forwards that header unchanged. A request that reaches the api
  directly, as the sandbox does through the published port, does not come
  from web, so it is keyed on its own address whatever header it carries.
  A tenant behind a customer load balancer must configure both hops, or the
  load balancer becomes every client and the tenant shares one bucket and
  one audit address again. Tell Caddy to keep the balancer's header, in the
  Caddyfile's global block:

  ```
  servers {
  	trusted_proxies static 10.20.0.0/24
  }
  ```

  Caddy then appends the balancer's address, so also set
  `EARNIE_TRUSTED_PROXIES=web,10.20.0.0/24` in `tenant.env`. Use the
  balancer's own source range, never a range clients can send from.
- `web` gets its own environment. It never reads `tenant.env`, because Next.js
  honours `PORT` and the api's 8080 would move it off 3000. Of the auth
  settings it receives only the two its login page mirrors,
  `EARNIE_PASSWORD_AUTH_ENABLED` and `OIDC_ISSUER`; never a client credential.
- Dependency builds run on `SCANS_SANDBOX_SUBNET` (default
  `172.31.250.0/24`). `sandbox-egress`, the one service with host networking
  and `NET_ADMIN`, lets that subnet open connections only to the staging
  endpoint, `SCANS_SANDBOX_MIRROR_CIDRS` and the ranges in
  `sandbox-registries.txt` on TCP 80 and 443. It refuses the host, the cloud
  metadata endpoint, private networks and everything else, and re-applies the
  rules every 30 seconds. `worker-crypto` creates the subnet's network without
  masquerade, so the subnet has no route out until those rules are in place,
  and it waits for `sandbox-egress` to be healthy. An empty
  `SCANS_SANDBOX_SUBNET` leaves egress open and every scan says so.
- Sandbox budgets stay strictly ordered, exec timeout < job deadline < crypto
  timeout, or the worker refuses to boot (ADR 0077).
- The `otel-collector` never reads `tenant.env`. It receives only its
  endpoint, its authorization header, the tenant and host names and the
  scrape targets. It runs as `nobody` and mounts only the host's `/proc` and
  `/sys`, read-only, so it cannot read another process's environment, the
  Docker socket or the containers' configuration. It starts only when
  `EARNIE_OTLP_ENDPOINT` is set. What it ships and how to read it:
  [Observe Earnie](../../docs/deploy/day2-ops.md#observe-earnie).
- Without telemetry, every service logs through `json-file` with a size cap,
  so a chatty service cannot fill the host's disk.
- With telemetry, `render-env.sh` sets `COMPOSE_FILE=compose.yaml:compose.logs.yaml`.
  Every service except the collector then logs through Docker's `fluentd`
  driver to `127.0.0.1:24224`, the one port the collector publishes, on the
  host's loopback only.
  - The Docker daemon pushes the lines, so the collector needs no socket and
    no `/var/lib/docker`.
  - The driver is `fluentd-async`: a collector that is down, slow or still
    starting never delays or fails a container start.
  - The daemon keeps up to `fluentd-buffer-limit` (8192) lines per container
    in memory and delivers them when the collector returns. It drops the
    excess, so a long outage loses lines but never blocks a service.
  - `docker logs` and `docker compose logs` keep working. The collector itself
    keeps `json-file`.
  - Run compose from this directory, or pass both files. A bare
    `-f compose.yaml` on `up` puts `json-file` back.
- Everything that must survive the host lives under `EARNIE_DATA_DIR`
  (scans, crypto caches, ai scratch, caddy certificates, the onprem database).

## Run

```
./install.sh
```

A first run creates `tenant.env` from `tenant.env.example` and asks for what
it cannot derive: the host name, the SCANOSS API key, the first admin's email
and password (Enter generates one, printed once at the end), the
organisation name and the modules. Each answer can come from an environment
variable of the same name instead, or from a prefilled `tenant.env`; without
a terminal a missing one stops the run, which names it and writes nothing.
The run then generates the secrets and, unless `DB_URL` names a database,
the bundled postgres and its password, and `render-env.sh` derives the rest:
`EARNIE_VERSION` from the bundle's `VERSION` file, `EARNIE_TLS` from whether
`cert.pem` and `key.pem` are in `EARNIE_DATA_DIR/tls`, `EARNIE_ACME_EMAIL`
from the admin email, `EARNIE_ONPREM_POSTGRES` from `DB_URL`, `DOCKER_GID`
from the docker group, `DOCKER_BRIDGE_IP` from the bridge network,
`DOCKER_CLI` from PATH, and `SANDBOX_CPUS`, `WORKER_CRYPTO_CPUS` and
`WORKER_AI_CPUS` from the host's cores. `DB_URL` and `EARNIE_DATA_DIR` come
from the environment or the file but are never asked; the run says which
keys it took from the environment and when it falls back to the bundled
postgres. A value
already set in `tenant.env` is never changed, so a `tenant.env` rendered
elsewhere (earnie-tenants) runs as is, and a second run asks nothing, pulls
nothing and only applies what changed. A new bundle takes `tenant.env` over
by itself, from the directory the `earnie-api` container was started from or
else the newest sibling bundle, and appends, at their defaults, the keys the
new release adds; an installation without a `tenant.env` to take over
refuses a fresh one. `install.sh` writes a literal `$` as `$$`, which is how
compose reads one, and URL-encodes the generated postgres password in
`DB_URL`.

`render-env.sh` refuses, before anything starts, what a container would only
reject behind `--wait`: a host name that is not a bare DNS name, a module
that does not exist or a list with spaces, a `DB_URL` on localhost, a short
`JWT_SECRET`, a KEK (SSO, integrations or notifications) that is not 64 hex characters, an admin password outside
12 to 128 characters, an incomplete OIDC trio, no sign-in method at all,
`SANDBOX_CPUS` or a worker's CPUs above the host's cores with that module,
a `DOCKER_GID` that is not the socket's group or a `DOCKER_BRIDGE_IP` that is
not the bridge's address, and an `EARNIE_VERSION` that differs from the
bundle's. After `compose up`, `install.sh` fetches `https://EARNIE_HOST/healthz`
on this host, resolved to 127.0.0.1 and verified against the custom
certificate itself, so a certificate Caddy could not get or cannot use is
reported instead of "running", with the hint matching curl's error; a
service that is unhealthy, restarting or exited with an error has its log
printed. With crypto, the sandbox and worker memory limits must fit the
host's RAM.

Each `vX.Y.Z` release publishes this directory, with `VERSION` inside, as
`earnie-bundle-vX.Y.Z.tar.gz` on `https://get.earnie.dev/server/vX.Y.Z/`,
where `curl -fsSL https://get.earnie.dev/server/install.sh | sh` fetches it
and runs `./install.sh`, which pulls the public images, and as
`earnie-bundle-vX.Y.Z.tar.zst` on the GitHub release and the SFTP server
(the host needs `zstd` to extract it), next to the image archive for on-prem
hosts, `earnie-onprem-images-vX.Y.Z.tar.zst`, without `earnie-api-ai`. A
host without internet runs `./install.sh <archive>` with that archive:
`install.sh` checks it against the release's `.sha256` and `.images.txt`
beside it, then loads it when an image is missing. `ai` is refused, before
`tenant.env` is written, when its image is not served by the registry or not
in the archive: AI provenance isn't available for self-hosted installs yet.
An older bundle refuses to start on data a newer release has migrated. The steps are in `docs/deploy/releasing.md`, section 6.

Self-hosted customers install the stable release, which
`https://get.earnie.dev/server/stable` names, rather than the newest weekly
one. Stable is a weekly release promoted after a green upgrade test; the
current and the previous stable are supported (`docs/deploy/releasing.md`,
section 8).

### TLS

`EARNIE_TLS=acme`, the default, has Caddy obtain the certificate from Let's
Encrypt, which needs `EARNIE_HOST` to resolve publicly, ports 80 and 443
reachable from the internet and `EARNIE_ACME_EMAIL`. A host on an internal
name or behind an internal CA sets `EARNIE_TLS=custom` and puts the full
chain, server certificate first, in `cert.pem` and its unencrypted key in
`key.pem`, in `EARNIE_TLS_DIR` (empty means `EARNIE_DATA_DIR/tls`). Caddy
mounts that directory read-only and never contacts a CA. To renew, replace
both files and run `docker compose restart caddy`. `render-env.sh` refuses any
other mode, acme without any contact address (`EARNIE_ACME_EMAIL`, else
`EARNIE_INITIAL_ADMIN_EMAIL`) and custom without both files.

A load balancer in front either passes TCP through to 443 or re-encrypts to
it with a certificate it trusts. Plain HTTP from the balancer is redirected
back to HTTPS. Caddy answers a handshake without SNI, which re-encrypting
balancers and their health checks may send, with the `EARNIE_HOST`
certificate (`default_sni`).

### Several tenants on one host

A hosting operator can run several tenants on one host, each from its own
bundle directory with its own `tenant.env`. What is host-wide gets a value per
tenant: `EARNIE_TENANT` (the compose project), `EARNIE_DATA_DIR`,
`CADDY_HTTP_PORT`, `API_BRIDGE_PORT`, `EARNIE_FLUENTD_PORT` and, with crypto,
`SCANS_SANDBOX_SUBNET`, `SCANS_SANDBOX_NETWORK` and `SANDBOX_EGRESS_CHAIN`.
`EARNIE_TLS=proxy` adds `compose.proxy.yaml`: Caddy keeps the upload cap, the
headers and the proxy to web, but serves plain http on the loopback and trusts
the forwarded client address and scheme from a private address. One TLS proxy
on the host (the operator's, not part of this bundle) holds every tenant's
certificate and forwards each `EARNIE_HOST` to its port. `install.sh` probes
that port instead of https.

`EARNIE_MODULES=oss,crypto` turns on the crypto worker, the module toggle and
the api's queue switch together, and `ai` in the same list does the same for
`worker-ai` and `SCANS_AI_QUEUED`; `render-env.sh` writes them into `.env`, so a
plain `docker compose up -d` in this directory stays correct afterwards. Edit
`tenant.env`, never `.env`, and rerun `install.sh`.
`enrichment` in the same list is a module toggle with no worker: it enriches
the components crypto and ai find with licences and vulnerabilities (ADR 0086).

## Sizing

| purchased scanners | host |
|---|---|
| oss | 2 vCPU, 4 GB |
| oss, crypto | 16 vCPU, 32 GB |

The crypto numbers come from the measured sandbox budget in
`docs/deploy/crypto-capable-image.md`: 14 cores buy a 10-minute cold
dependency phase on a 131-dependency Java project, and memory peaks near
7.5 GiB regardless of cores.

## Known gaps

- Sandbox egress allows the public registries by their CDNs' published
  ranges, because their addresses rotate. A build can therefore reach
  anything else hosted on Cloudflare, Fastly, GitHub or Google's own
  services on 80 and 443. DNS goes through Docker's resolver on the host and
  is not filtered. Limiting egress by domain needs a filtering proxy.
- Logs ship through the Docker daemon's `fluentd` driver, so a container's
  lines reach the collector only after it starts: a collector outage longer
  than the 8192-line buffer drops the oldest-unsent excess, and a line in
  flight when the connection breaks can be lost.
- Disk usage is read through empty probe directories (the `fsprobe-root`
  Docker volume for `/`, and `$EARNIE_DATA_DIR/.fsprobe`), because `statfs`
  on any path reports its whole filesystem. The collector cannot list a
  single data or host file. The data series exists only when
  `EARNIE_DATA_DIR` is its own mount point. The series and their labels are
  in [Disk series](../../docs/deploy/day2-ops.md#disk-series).
- A model file above `SCANS_AI_MAX_MODEL_MB` (3072) is reported too large
  and is not fingerprinted. The `worker-ai` defaults (`WORKER_AI_CPUS=4`,
  `WORKER_AI_MEM_LIMIT=16g`, `SCANS_AI_MAX_CONCURRENT=2`) are sized for two
  3 GB models at once. A larger cap needs a new measurement (ADR 0082).
