#!/usr/bin/env bash
# Install or upgrade an Earnie tenant on this host.
#
#   ./install.sh                 first run: asks what it cannot derive, then installs;
#                                later runs apply a changed tenant.env or a new bundle.
#                                Images are pulled from the registry.
#   ./install.sh images.tar.zst  load the images from this archive instead (a host
#                                without internet; the archive comes from SCANOSS's SFTP)
#
# tenant.env is taken from the installed bundle directory (an upgrade) or
# created from tenant.env.example. An empty value in its "fill in" section is
# taken from the environment, asked on a terminal, or refused; the secrets,
# the bundled database's password and, on request, the admin password are
# generated. A value that is already set is never changed. An archive is
# checked against the release's .sha256 and .images.txt first. Needs Docker
# Engine 29 or later with the compose plugin.
set -euo pipefail
archive="${1:-}"
[ -z "$archive" ] || [ -f "$archive" ] || { echo "$archive: no such file" >&2; exit 1; }
[ -z "$archive" ] || archive=$(readlink -f "$archive")
cd "$(dirname "$0")"
min_free_gib=10
modules_known="oss crypto ai enrichment cra"

fail() { printf '%s\n' "$*" >&2; exit 1; }
# The last line wins, as it does for compose.
read_var() { sed -n "s/^$1=//p" tenant.env | tail -1; }
example_var() { sed -n "s/^$1=//p" tenant.env.example | tail -1; }
# Set KEY=VALUE on the last KEY= line of tenant.env, or append it; a
# commented-out "# KEY=" line is left as it is. A literal $ is written as $$,
# which is how compose reads one; "raw" takes a value already in that form.
set_var() {
  local value=$2 target
  [ "${3:-}" = raw ] || value=${value//$/\$\$}
  target=$(readlink -f tenant.env)
  [ -z "$(tail -c1 "$target")" ] || echo >> "$target"
  (umask 077; export K="$1" V="$value"; tac "$target" | awk '
    BEGIN { k = ENVIRON["K"]; v = ENVIRON["V"] }
    !done && $0 ~ ("^" k "=") { print k "=" v; done = 1; next }
    { print }
    END { if (!done) print k "=" v }' | tac > "$target.tmp")
  mv "$target.tmp" "$target"
  chmod 600 "$target"
}
random_hex() { od -An -N32 -tx1 /dev/urandom | tr -d ' \n'; }
urlencode() { # for a URL's user, password and database fields
  local s=$1 out="" c i
  for ((i = 0; i < ${#s}; i++)); do
    c=${s:i:1}
    case "$c" in [A-Za-z0-9._~-]) out+=$c ;; *) out+=$(LC_ALL=C printf '%%%02X' "'$c") ;; esac
  done
  printf '%s' "$out"
}
free_gib() { # of the filesystem holding the nearest existing ancestor of $1
  local dir=$1
  while [ ! -d "$dir" ]; do dir=$(dirname "$dir"); done
  df -Pk "$dir" | awk 'NR == 2 { printf "%d", $4 / 1048576 }'
}

# ---- host -------------------------------------------------------------------
command -v docker >/dev/null || fail "docker is required: install Docker Engine from https://docs.docker.com/engine/install/"
docker info >/dev/null 2>&1 || fail "cannot talk to the Docker daemon: is it running, and are you root or in the docker group? (sudo usermod -aG docker ${USER:-$(id -un)}, then log in again)"
server=$(docker version --format '{{.Server.Version}}')
[ "${server%%.*}" -ge 29 ] 2>/dev/null || fail "Docker Engine 29 or later is required, this host runs $server: install it from https://docs.docker.com/engine/install/ (the distribution's package is too old for the dependency sandbox)"
docker compose version >/dev/null 2>&1 || fail "the docker compose plugin is required: install docker-compose-plugin from the same repository as Docker Engine"
[ -f tenant.env.example ] || fail "tenant.env.example not found: run this from the bundle directory"

# ---- tenant.env -------------------------------------------------------------
if [ ! -f tenant.env ]; then
  # The installation already on this host, if any: the bundle directory its
  # earnie-api container was started from, else the newest sibling bundle.
  tenant=${EARNIE_TENANT:-$(example_var EARNIE_TENANT)}
  installed=$(docker ps -a --filter "label=com.docker.compose.project=$tenant" --filter label=com.docker.compose.service=earnie-api --format '{{.Label "com.docker.compose.project.working_dir"}}' | head -1)
  data_dir=${EARNIE_DATA_DIR:-$(example_var EARNIE_DATA_DIR)}; data_dir=${data_dir:-/var/lib/earnie}
  previous=""
  if [ -n "$installed" ]; then
    [ -f "$installed/tenant.env" ] || fail "Earnie is installed from $installed but its tenant.env is gone: restore it from your backup into $PWD; new secrets would lock the existing data"
    # Migrations only go forward: an older bundle must not start on this data.
    if [ -s "$installed/VERSION" ] && [ -s VERSION ] && [ "$(cat "$installed/VERSION")" != "$(cat VERSION)" ] \
       && [ "$(printf '%s\n' "$(cat "$installed/VERSION")" "$(cat VERSION)" | sort -V | tail -1)" = "$(cat "$installed/VERSION")" ]; then
      fail "Earnie $(cat "$installed/VERSION") runs from $installed and this bundle is $(cat VERSION), an older release: the database cannot go back. Run the installer from $installed, or restore the backup taken before $(cat "$installed/VERSION") first"
    fi
    previous=$installed/tenant.env
  else
    previous=$(ls -t ../earnie-v*/tenant.env 2>/dev/null | head -1 || true)
  fi
  if [ -n "$previous" ]; then
    (umask 077; cp "$previous" tenant.env) || fail "cannot copy $previous: sudo chown ${USER:-$(id -un)} $previous $PWD"
    echo "==> took tenant.env from $(dirname "$previous")"
  elif [ -d "$data_dir/postgres" ] || [ -d "$data_dir/caddy" ]; then
    fail "$data_dir holds the data of an Earnie installation but there is no tenant.env: copy it from that installation's bundle directory, new secrets would lock that data. If it was never used, remove $data_dir/postgres and $data_dir/caddy"
  else
    (umask 077; cp tenant.env.example tenant.env) || fail "cannot write in $PWD: sudo chown -R ${USER:-$(id -un)} $PWD"
    echo "==> created tenant.env from tenant.env.example"
  fi
fi
chmod 600 tenant.env 2>/dev/null || fail "tenant.env must be yours to write: sudo chown ${USER:-$(id -un)} tenant.env"
[ -z "$(tail -c1 tenant.env)" ] || echo >> tenant.env
# A key this release adds, at its default; a key already there, set,
# empty or commented out, stays as it is.
grep -E '^[A-Z][A-Z0-9_]*=' tenant.env.example | while IFS= read -r line; do
  grep -qE "^(# ?)?${line%%=*}=" tenant.env || echo "$line" >> tenant.env
done
interactive=0; [ -t 0 ] && interactive=1
first_run=0; [ -n "$(read_var EARNIE_PASSWORD_AUTH_ENABLED)" ] || first_run=1
version=$(cat VERSION 2>/dev/null || read_var EARNIE_VERSION)
# The question lists the scanners, which cost resources: oss, crypto, and ai
# only when its image is at hand (in the archive's list, already loaded, or
# served by the registry; it is not yet published for self-hosted installs,
# earnie#1598). enrichment is never asked: it is always on, and the API key
# decides what it returns. A preset EARNIE_MODULES is kept as it is.
no_ai="AI provenance isn't available for self-hosted installs yet; choose modules without ai"
ai_image=$(read_var EARNIE_API_AI_IMAGE); ai_image=${ai_image:-ghcr.io/scanoss/earnie/earnie-api-ai:$version}
modules_offered="oss crypto"
if [ "$interactive" = 1 ] && [ -z "$(read_var EARNIE_MODULES)" ]; then
  if [ -n "$archive" ]; then
    list="${archive%.tar.*}.images.txt"
    { [ ! -f "$list" ] || grep -Fqx "$ai_image" "$list"; } && modules_offered="$modules_offered ai"
  elif docker image inspect "$ai_image" >/dev/null 2>&1 || timeout 30 docker manifest inspect "$ai_image" >/dev/null 2>&1; then
    modules_offered="$modules_offered ai"
  fi
fi
# Whether Caddy will ask Let's Encrypt: no custom certificate in place and
# EARNIE_TLS not set to custom. Let's Encrypt refuses some contact addresses.
tls_dir=$(read_var EARNIE_TLS_DIR); data_dir=$(read_var EARNIE_DATA_DIR); data_dir=${data_dir:-${EARNIE_DATA_DIR:-/var/lib/earnie}}
tls_dir=${tls_dir:-$data_dir/tls}
acme=1; { [ "$(read_var EARNIE_TLS)" = custom ] || [ "$(read_var EARNIE_TLS)" = proxy ] || { [ -s "$tls_dir/cert.pem" ] && [ -s "$tls_dir/key.pem" ]; } || [ -n "$(read_var EARNIE_ACME_EMAIL)" ] || [ -n "${EARNIE_ACME_EMAIL:-}" ]; } && acme=0
missing=""; from_env=""
declare -A answer
# ask KEY "prompt" [default] [secret]: an empty KEY is taken from the process
# environment, then the terminal, then the default. A terminal asks again
# until the answer is valid; nothing is written until every answer is in, so
# a refused run leaves tenant.env as it was. Only the password may stay empty.
why_invalid() { # prints the rule an answer breaks, nothing when it is fine
  case "$2" in \"*|\'*) echo "cannot start with a quote; compose would read it"; return ;; *" #"*) echo "cannot contain ' #'; compose reads a comment there"; return ;; esac
  case "$1" in
    EARNIE_HOST) printf '%s' "$2" | grep -qE '^[A-Za-z0-9.-]+$' || echo "a bare DNS name such as earnie.example.com, no https://, path or spaces" ;;
    EARNIE_INITIAL_ADMIN_EMAIL) printf '%s' "$2" | grep -qE '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' || echo "an email address"
            [ "$acme" = 0 ] || case "$2" in *@example.com|*@example.org|*.local|*.internal|*.lan|*.corp|*.home|*.localdomain) echo "Let's Encrypt refuses a contact at example.com or an internal domain; it is the certificate's contact unless EARNIE_ACME_EMAIL is set" ;; esac ;;
    EARNIE_INITIAL_ADMIN_PASSWORD) { [ "${#2}" -ge 12 ] && [ "${#2}" -le 128 ]; } || echo "12 to 128 characters" ;;
    EARNIE_MODULES) case ",$2," in *,,*) echo "an empty entry in the list; they are $(printf '%s' "$modules_offered" | tr ' ' ','), comma-separated" ;; *) for module in $(printf '%s' "$2" | tr ',' ' '); do case " $modules_known " in *" $module "*) ;; *) echo "'$module' is not a module this release can run here; they are $(printf '%s' "$modules_offered" | tr ' ' ',')" ;; esac; done ;; esac ;;
    DB_URL) printf '%s' "$2" | grep -qE '^postgres(ql)?://[^/]+/' || echo "postgres://user:password@host:5432/db"
            if printf '%s' "$2" | grep -qE '@(localhost|127\.0\.0\.1|\[?::1\]?)[:/]'; then echo "localhost inside a container is the container itself; use the server's address or DNS name"; fi ;;
  esac
}
ask() {
  local key=$1 prompt=$2 default=${3:-} secret=${4:-} value problem
  value=$(read_var "$key")
  [ -n "$value" ] && return
  value=${!key:-}
  [ "$key" != EARNIE_MODULES ] || value=$(printf '%s' "$value" | tr -d ' ')
  if [ -n "$value" ]; then problem=$(why_invalid "$key" "$value"); [ -z "$problem" ] || fail "$key: $problem"; from_env="$from_env $key"; fi
  if [ -z "$value" ] && [ "$interactive" = 1 ] && [ -n "$prompt" ]; then
    while :; do
      if [ -n "$secret" ]; then IFS= read -r -s -p "$prompt${default:+ [$default]}: " value || fail "no answer"; echo; else IFS= read -r -p "$prompt${default:+ [$default]}: " value || fail "no answer"; fi
      value=${value:-$default}
      [ "$key" != EARNIE_MODULES ] || value=$(printf '%s' "$value" | tr -d ' ')
      [ -n "$value" ] || [ "$key" = EARNIE_INITIAL_ADMIN_PASSWORD ] || { echo "required" >&2; continue; }
      [ -n "$value" ] || break   # Enter on the password: one is generated below
      problem=$(why_invalid "$key" "$value"); [ -z "$problem" ] || { echo "$problem" >&2; continue; }
      break
    done
  fi
  value=${value:-$default}
  [ -n "$value" ] || { [ "$key" = EARNIE_INITIAL_ADMIN_PASSWORD ] || [ -z "$prompt" ] || missing="$missing $key"; return; }
  answer[$key]=$value
}
ask EARNIE_HOST "DNS name users will type (such as earnie.example.com)"
host=${answer[EARNIE_HOST]:-$(read_var EARNIE_HOST)}
ask SCANOSS_API_KEY "SCANOSS API key" "" secret
ask EARNIE_INITIAL_ADMIN_EMAIL "Administrator email (the first user, who signs in with it)"
# Asked once, with Enter generating one: the first run records the sign-in
# method, and the password may be cleared after it.
generated_password=""
if [ "$first_run" = 1 ] && [ -z "$(read_var OIDC_ISSUER)" ]; then
  ask EARNIE_INITIAL_ADMIN_PASSWORD "Administrator password (to sign in; 12 to 128 characters; Enter generates one)" "" secret
  if [ -z "$(read_var EARNIE_INITIAL_ADMIN_PASSWORD)" ] && [ -z "${answer[EARNIE_INITIAL_ADMIN_PASSWORD]:-}" ]; then
    generated_password=$(random_hex | head -c 24); answer[EARNIE_INITIAL_ADMIN_PASSWORD]=$generated_password
  fi
fi
# An irreversible name is suggested on a terminal and refused without one.
org_default=""; [ "$interactive" = 1 ] && org_default=$(printf '%s' "${host#earnie.}" | cut -d. -f1 | sed 's/./\U&/')
ask EARNIE_ORG_NAME "Organisation name (cannot be changed later)" "$org_default"
ask EARNIE_MODULES "Scanners bought, comma-separated: $(printf '%s' "$modules_offered" | tr ' ' ',')" oss
case ",${answer[EARNIE_MODULES]:-}," in ,,|*,enrichment,*) ;; *) answer[EARNIE_MODULES]="${answer[EARNIE_MODULES]},enrichment" ;; esac
# Taken from the environment or the file, never asked: the bundled postgres
# and the default data directory serve without them.
ask DB_URL ""
ask EARNIE_DATA_DIR ""
ask EARNIE_ACME_EMAIL ""
[ -z "$missing" ] || fail "tenant.env needs:$missing. Set them in the file or export them, then run ./install.sh again"
# ai needs an image that is not yet available for self-hosted installs: the
# archive's list says whether it holds it, the registry whether it serves it.
case ",${answer[EARNIE_MODULES]:-$(read_var EARNIE_MODULES)}," in *,ai,*)
  if [ -n "$archive" ]; then
    list="${archive%.tar.*}.images.txt"
    [ ! -f "$list" ] || grep -Fqx "$ai_image" "$list" || fail "$no_ai ($ai_image is not in $archive)"
  elif ! docker image inspect "$ai_image" >/dev/null 2>&1; then
    timeout 30 docker manifest inspect "$ai_image" >/dev/null 2>&1 || fail "$no_ai ($ai_image is not served by the registry)"
  fi ;;
esac
[ -z "$from_env" ] || echo "==> from the environment:$from_env"
for key in "${!answer[@]}"; do set_var "$key" "${answer[$key]}"; done

# The database: the bundled postgres with a generated password unless DB_URL
# names one. The parts are read back as compose reads them, so no re-escaping.
if [ -z "$(read_var DB_URL)" ]; then
  data_dir=$(read_var EARNIE_DATA_DIR)
  echo "==> DB_URL is empty: running the bundled postgres on ${data_dir:-/var/lib/earnie}/postgres"
  [ -n "$(read_var ONPREM_PG_PASSWORD)" ] || set_var ONPREM_PG_PASSWORD "$(random_hex)"
  pg_user=$(read_var ONPREM_PG_USER); pg_db=$(read_var ONPREM_PG_DB); pg_password=$(read_var ONPREM_PG_PASSWORD)
  set_var DB_URL "postgres://$(urlencode "${pg_user:-earnie}"):$(urlencode "${pg_password//\$\$/\$}")@postgres:5432/$(urlencode "${pg_db:-earnie}")" raw
fi
# The secrets, once; a KEK that changes orphans what it encrypts.
for key in JWT_SECRET EARNIE_SSO_KEK_HEX EARNIE_INTEGRATIONS_KEK_HEX EARNIE_NOTIFICATIONS_KEK_HEX; do
  [ -n "$(read_var "$key")" ] || set_var "$key" "$(random_hex)"
done
# The sign-in method: the password form unless SSO is configured.
if [ -z "$(read_var EARNIE_PASSWORD_AUTH_ENABLED)" ]; then
  if [ -n "$(read_var OIDC_ISSUER)" ]; then set_var EARNIE_PASSWORD_AUTH_ENABLED false; else set_var EARNIE_PASSWORD_AUTH_ENABLED true; fi
fi
if [ "$first_run" = 1 ] && [ -z "$(read_var OIDC_ISSUER)" ] && [ -z "$(read_var EARNIE_INITIAL_ADMIN_PASSWORD)" ]; then
  echo "note: no EARNIE_INITIAL_ADMIN_PASSWORD and no SSO: only a user who already has a password can sign in" >&2
fi

./render-env.sh
env_var() { sed -n "s/^$1=//p" .env | tail -1; }
version=$(env_var EARNIE_VERSION)
tls_mode=$(env_var EARNIE_TLS)
if [ "$tls_mode" = custom ] && command -v curl >/dev/null && [ ! -r "$tls_dir/cert.pem" ]; then
  fail "$tls_dir/cert.pem is not readable by ${USER:-$(id -un)}, so $host could not be checked after the start: sudo chmod 644 $tls_dir/cert.pem"
fi
[ "$first_run" = 0 ] || [ "$(free_gib "$data_dir")" -ge "$min_free_gib" ] || fail "$data_dir has under ${min_free_gib} GiB free: mount a volume of 50 GB or more there, or point EARNIE_DATA_DIR at one"

# ---- images -----------------------------------------------------------------
images=$(docker compose config --images | sort -u) || fail "docker compose cannot read the bundle"
missing_images=""
for image in $images; do
  docker image inspect "$image" >/dev/null 2>&1 || missing_images="$missing_images $image"
done
if [ -n "$missing_images" ]; then
  docker_root=$(docker info --format '{{.DockerRootDir}}')
  [ "$(free_gib "$docker_root")" -ge "$min_free_gib" ] || fail "$docker_root has under ${min_free_gib} GiB free: the images need that much, free some space or move Docker's data-root"
  if [ -n "$archive" ]; then
    # The list beside the archive says what it holds, before the long load,
    # and the release's checksums say whether the download is whole.
    list="${archive%.tar.*}.images.txt"
    for image in $missing_images; do
      [ -f "$list" ] && ! grep -Fqx "$image" "$list" && case "$image" in
        */earnie-api-ai:*) fail "$no_ai ($image is not in $archive)" ;;
        *) fail "$image is not in $archive ($list): the archive is for another release, get this release's from SCANOSS's SFTP" ;;
      esac
    done
    sums="${archive%.tar.*}.sha256"
    if [ -f "$sums" ]; then
      echo "==> checking $sums"
      (cd "$(dirname "$archive")" && sha256sum -c --ignore-missing --quiet "$sums") || fail "a release file is damaged or incomplete (see above): download it again"
    fi
    echo "==> loading images from $archive"
    docker load -i "$archive" || fail "docker load failed on $archive: the download may be incomplete, check it with sha256sum -c, or the disk under $docker_root is full"
  else
    echo "==> pulling images"
    docker compose pull || fail "could not pull the images: this host needs internet access to the registry. Without it, get earnie-onprem-images-$version.tar.zst from SCANOSS's SFTP and run ./install.sh <archive>"
  fi
  for image in $missing_images; do
    docker image inspect "$image" >/dev/null 2>&1 && continue
    case "$image" in
      */earnie-api-ai:*) fail "$no_ai ($image was not loaded)" ;;
      *) [ -n "$archive" ] && fail "$image is still missing after loading $archive: the archive is for another release" || fail "$image is still missing after the pull" ;;
    esac
  done
else
  echo "==> images for $version present"
fi

# ---- start ------------------------------------------------------------------
[ -d "$data_dir" ] || mkdir -p "$data_dir" 2>/dev/null || true
echo "==> starting $(read_var EARNIE_TENANT) $version at https://${host}"
if ! docker compose up -d --remove-orphans --wait; then
  docker compose ps -a --format '{{.Service}} {{.Status}}' | while read -r service status; do
    case "$status" in *unhealthy*|*Restarting*|"Exited ("[1-9]*) echo "--- $service: $status" >&2; docker compose logs --no-log-prefix --tail=15 "$service" >&2 ;; esac
  done
  fail "a service did not become healthy; the lines above say why"
fi
# A certificate that Caddy could not get or cannot use only shows up here:
# fetched on this host, by name, so DNS is not needed yet.
https_port=$(read_var CADDY_HTTPS_PORT); https_port=${https_port:-443}
site="https://${host}"; [ "$https_port" = 443 ] || site="https://${host}:${https_port}"
# Behind the host's TLS proxy, Caddy answers plain http on its loopback port;
# users still reach https://host through the proxy.
probe="$site" probe_port=$https_port
if [ "$tls_mode" = proxy ]; then
  site="https://${host}"; probe_port=$(read_var CADDY_HTTP_PORT); probe="http://${host}:${probe_port}"
fi
state="is running"
if command -v curl >/dev/null; then
  trust=(-k); [ "$tls_mode" != custom ] || trust=(--cacert "$tls_dir/cert.pem")
  echo "==> waiting for $probe/healthz"
  for attempt in $(seq 1 30); do
    curl_rc=0; curl_err=$(curl -fsS "${trust[@]}" --noproxy '*' --max-time 10 -o /dev/null --resolve "${host}:${probe_port}:127.0.0.1" "$probe/healthz" 2>&1) || curl_rc=$?
    [ "$curl_rc" != 0 ] || break
    if [ "$attempt" -ge 30 ]; then
      echo "curl: $curl_err" >&2
      case "$curl_rc:$tls_mode" in
        22:*) fail "$probe/healthz answers with an error: the api or the database is not ready, see docker compose logs earnie-api postgres" ;;
        35:acme|60:acme|58:acme) fail "no usable certificate: Caddy could not get one from Let's Encrypt yet, for ${host} with the contact $(env_var EARNIE_ACME_EMAIL) (docker compose logs caddy). ${host} must resolve to this server from the internet with ports 80 and 443 open, or put your own cert.pem and key.pem in ${tls_dir} and run ./install.sh again" ;;
        35:*|60:*|58:*) fail "no usable certificate: docker compose logs caddy says whether the certificate in ${tls_dir} is usable, and it must cover ${host}" ;;
        *) fail "$probe/healthz does not answer (curl exit $curl_rc): docker compose logs caddy says why" ;;
      esac
    fi
    sleep 3
  done
else
  state="is up (curl is not installed, so $site was not probed)"
fi
admin_email=$(read_var EARNIE_INITIAL_ADMIN_EMAIL)
password_note=""
if [ -n "$generated_password" ]; then password_note=" with the password $generated_password"
elif [ -n "$(read_var EARNIE_INITIAL_ADMIN_PASSWORD)" ]; then password_note=" with the password in tenant.env"; fi
echo "==> Earnie $version $state: sign in at ${site}${admin_email:+ as $admin_email}${password_note}"
[ -z "$password_note" ] || echo "    EARNIE_INITIAL_ADMIN_PASSWORD is set again on every run while it is in tenant.env; clear it once you have signed in"
