#!/usr/bin/env bash
# Contract test for the tenant compose bundle. Renders the bundle with each
# profile set and asserts the invariants the VM model depends on.
set -euo pipefail
repo_root=$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)
source_bundle="$repo_root/deploy/compose"
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cp -r "$source_bundle/." "$work/"
bundle="$work"
env_file="$bundle/tenant.env"

cp "$bundle/tenant.env.example" "$env_file"
{
  echo "EARNIE_HOST=tenant.localhost"
  echo "EARNIE_VERSION=latest"
  echo "EARNIE_INITIAL_ADMIN_EMAIL=admin@example.com"
  echo "EARNIE_INITIAL_ADMIN_PASSWORD=contract-test-password"
  echo "EARNIE_PASSWORD_AUTH_ENABLED=true"
  echo "DOCKER_GID=$(stat -c %g /var/run/docker.sock 2>/dev/null || echo 5000)"
  echo "DB_URL=postgres://earnie:earnie@postgres:5432/earnie?sslmode=disable"
  echo "JWT_SECRET=$(printf 'a%.0s' $(seq 1 64))"
  echo "EARNIE_SSO_KEK_HEX=$(printf '0%.0s' $(seq 1 64))"
  echo "EARNIE_INTEGRATIONS_KEK_HEX=$(printf '1%.0s' $(seq 1 64))"
  echo "EARNIE_NOTIFICATIONS_KEK_HEX=$(printf '2%.0s' $(seq 1 64))"
} >>"$env_file"

# Render as an operator does: render-env.sh writes .env, then plain compose.
render() {
  sed -i "s/^EARNIE_MODULES=.*/EARNIE_MODULES=$1/; s/^EARNIE_ONPREM_POSTGRES=.*/EARNIE_ONPREM_POSTGRES=${2:-false}/; s/^ONPREM_PG_PASSWORD=.*/ONPREM_PG_PASSWORD=pw/; s|^EARNIE_OTLP_ENDPOINT=.*|EARNIE_OTLP_ENDPOINT=${3:-}|" "$env_file"
  "$bundle/render-env.sh" >/dev/null
  (cd "$bundle" && docker compose --project-name earnie-contract config --format json)
}

python3 - "$(render oss)" "$(render oss,crypto)" "$(render oss true)" "$(render oss,ai)" "$(render oss,crypto,ai)" "$(render oss,crypto false https://otlp.example.test/otlp)" "$(render crypto,enrichment)" "$bundle" <<'PY'
import json, sys, re, os

base, crypto, onprem, ai, both, telemetry, enriched = (json.loads(a) for a in sys.argv[1:8])
bundle_dir = sys.argv[8]

def services(cfg): return set(cfg["services"])
def svc(cfg, name): return cfg["services"].get(name, {})
def env(cfg, name): return svc(cfg, name).get("environment") or {}
def mounts(cfg, name): return [v.get("source", "") + ":" + v.get("target", "") for v in svc(cfg, name).get("volumes", [])]
def minutes(s):
    m = re.fullmatch(r"(\d+)m", s); assert m, f"expected minutes, got {s!r}"; return int(m.group(1))

failures = []
def check(cond, msg):
    if not cond: failures.append(msg)

check({"caddy", "web", "earnie-api", "migrate", "bootstrap", "data-init"} <= services(base), f"base services missing: {services(base)}")
check("worker-crypto" not in services(base), "an oss-only tenant gets no crypto worker")
check(not svc(base, "earnie-api").get("command"), "earnie-api takes no --queues, so it works the scans-selfcheck lane beside scans")
check(env(base, "earnie-api").get("SCANS_SELFCHECK_MAX_CONCURRENT_PIPELINES") == "2", "earnie-api bounds the Self-check pipeline lane")
check("postgres" not in services(base), "postgres must be behind the onprem profile")
check("worker-crypto" in services(crypto), "EARNIE_MODULES with crypto must add worker-crypto")
check("postgres" in services(onprem), "EARNIE_ONPREM_POSTGRES=true must add postgres")

w = svc(crypto, "worker-crypto")
check(w.get("command") == ["--worker", "--queues=scans-crypto,scans-crypto-selfcheck"], f"worker command: {w.get('command')}")
check(any(m.startswith("/var/run/docker.sock:") for m in mounts(crypto, "worker-crypto")), "worker must mount the docker socket")
check(not any("docker.sock" in m for m in mounts(crypto, "earnie-api")), "api must never mount the docker socket")
check("SCANS_CRYPTO_FINDER_PATH" in env(crypto, "worker-crypto"), "worker needs SCANS_CRYPTO_FINDER_PATH")
check("SCANS_CRYPTO_FINDER_PATH" not in env(crypto, "earnie-api"), "api must not receive SCANS_CRYPTO_FINDER_PATH (#785)")
check(env(crypto, "worker-crypto").get("SCANS_SANDBOX_IMAGE"), "worker needs SCANS_SANDBOX_IMAGE")
check(env(crypto, "worker-crypto").get("SCANS_SANDBOX_STAGING_URL", "").startswith("http://"), "worker needs a staging URL")
check(env(crypto, "earnie-api").get("SCANS_CRYPTO_QUEUED") == "true", "api must enqueue crypto to the worker when crypto is bought")
check(env(base, "earnie-api").get("SCANS_CRYPTO_QUEUED") == "false", "api must not enqueue crypto when no worker exists")

e = env(crypto, "worker-crypto")
check(minutes(e["SCANS_SANDBOX_EXEC_TIMEOUT"]) < minutes(e["SCANS_SANDBOX_JOB_DEADLINE"]) < minutes(e["SCANS_CRYPTO_TIMEOUT"]),
      "sandbox budgets must be strictly ordered: exec < deadline < crypto timeout")

g = svc(crypto, "sandbox-egress")
check("sandbox-egress" not in services(base) and g.get("profiles") == ["crypto"], "sandbox-egress runs with the crypto profile only")
check(g.get("network_mode") == "host", "sandbox-egress must run in the host network namespace, where DOCKER-USER is")
check(g.get("cap_drop") == ["ALL"] and g.get("cap_add") == ["NET_ADMIN"], f"sandbox-egress gets NET_ADMIN and nothing else, got {g.get('cap_add')}")
check(not g.get("env_file") and set(env(crypto, "sandbox-egress")) == {"SCANS_SANDBOX_SUBNET", "SCANS_SANDBOX_MIRROR_CIDRS", "SCANS_SANDBOX_STAGING_URL", "SANDBOX_EGRESS_CHAIN"},
      f"sandbox-egress must receive only its four settings, never tenant secrets, got {sorted(env(crypto, 'sandbox-egress'))}")
check(not any("docker.sock" in m for m in mounts(crypto, "sandbox-egress")), "sandbox-egress must never mount the docker socket")
check(g.get("restart") == "unless-stopped" and g.get("healthcheck", {}).get("test"), "sandbox-egress must come back after a reboot and report whether the rules hold")
check(env(crypto, "sandbox-egress").get("SCANS_SANDBOX_STAGING_URL") == env(crypto, "worker-crypto").get("SCANS_SANDBOX_STAGING_URL"),
      "sandbox-egress must allow exactly the staging URL the worker hands the sandbox")
check(env(crypto, "sandbox-egress").get("SCANS_SANDBOX_SUBNET") == env(crypto, "worker-crypto").get("SCANS_SANDBOX_SUBNET") != "",
      "a fresh tenant confines the sandbox: the worker and sandbox-egress share one non-empty SCANS_SANDBOX_SUBNET")
check(w.get("depends_on", {}).get("sandbox-egress", {}).get("condition") == "service_healthy", "worker-crypto must wait until the egress rules hold")

check(services(enriched) == services(crypto), "the enrichment module is a toggle, not a worker: it adds no service")
check(env(enriched, "earnie-api").get("SCANS_CRYPTO_QUEUED") == "true" and env(enriched, "earnie-api").get("SCANS_AI_QUEUED") == "false",
      "enrichment must not be read as a queued scanner")
check("worker-ai" not in services(base) and "worker-ai" not in services(crypto), "a tenant without ai gets no ai worker")
check("worker-ai" in services(ai), "EARNIE_MODULES with ai must add worker-ai")
check({"worker-crypto", "worker-ai"} <= services(both), "crypto and ai together start both workers")
a = svc(ai, "worker-ai")
check(a.get("profiles") == ["ai"], f"worker-ai must be behind the ai profile, got {a.get('profiles')}")
check(a.get("command") == ["--worker", "--queues=scans-ai,scans-ai-selfcheck"], f"ai worker command: {a.get('command')}")
check(re.fullmatch(r".*/earnie-api-ai:[^/]+", a.get("image", "")), f"worker-ai runs the ai image variant, got {a.get('image')}")
check(not any("docker.sock" in m for m in mounts(ai, "worker-ai")), "worker-ai must never mount the docker socket")
check(not a.get("group_add"), "worker-ai needs no docker group")
check(not a.get("tmpfs"), "ai scratch belongs on the data volume, not a tmpfs")
check(any(m.endswith(":/tmp") and m.startswith("/var/lib/earnie/") for m in mounts(ai, "worker-ai")), f"worker-ai /tmp must be a data-volume directory, got {mounts(ai, 'worker-ai')}")
check(any(m.endswith(":/var/lib/earnie/scans") for m in mounts(ai, "worker-ai")), "worker-ai reads the scans volume")
models_mount = next((m for m in mounts(base, "earnie-api") if m.endswith(":/var/lib/earnie/models")), None)
check(models_mount and models_mount.startswith("/var/lib/earnie/"), f"earnie-api stores Models on the data volume, got {mounts(base, 'earnie-api')}")
check(models_mount in mounts(ai, "worker-ai"), "worker-ai stages Models from the same directory the api stores them in (#1138)")
check(models_mount in mounts(base, "data-init"), "data-init creates the models directory")
check(env(base, "earnie-api").get("SCANS_MODELS_DIR") == "/var/lib/earnie/models" and env(ai, "worker-ai").get("SCANS_MODELS_DIR") == "/var/lib/earnie/models",
      "the api and the ai worker point SCANS_MODELS_DIR at the mount")
check("/var/lib/earnie/models" in " ".join(svc(base, "data-init").get("entrypoint", [])), "data-init makes and owns the models directory")
check(env(ai, "worker-ai").get("SCANS_AI_FINDER_PATH") == "/opt/ai-finder/bin/ai-finder-pro", "worker-ai points at the path the ai image installs")
check("SCANS_AI_FINDER_PATH" not in env(ai, "earnie-api"), "api must not receive SCANS_AI_FINDER_PATH")
check("SCANOSS_API_KEY" in env(ai, "worker-ai"), "worker-ai receives the tenant's SCANOSS key")
check(env(ai, "worker-ai").get("EARNIE_SKIP_MIGRATIONS") == "true", "worker-ai skips migrations")
check(env(ai, "earnie-api").get("SCANS_AI_QUEUED") == "true", "api must enqueue ai to the worker when ai is bought")
check(env(ai, "earnie-api").get("SCANS_CRYPTO_QUEUED") == "false", "ai alone must not queue crypto")
check(env(base, "earnie-api").get("SCANS_AI_QUEUED") == "false" and env(crypto, "earnie-api").get("SCANS_AI_QUEUED") == "false",
      "api must not enqueue ai when no ai worker exists")
check(env(both, "earnie-api").get("SCANS_CRYPTO_QUEUED") == "true" and env(both, "earnie-api").get("SCANS_AI_QUEUED") == "true",
      "crypto and ai together queue both")

ports = svc(base, "earnie-api").get("ports", [])
check(ports and all(p.get("host_ip") not in (None, "", "0.0.0.0", "::") for p in ports), f"api port must bind to the docker bridge only, got {ports}")
check(not svc(base, "web").get("ports"), "web must not publish a port; caddy fronts it")
check(env(base, "earnie-api").get("EARNIE_TRUSTED_PROXIES") == "web" and "web" in services(base),
      "the api must trust X-Forwarded-For from the web service only, or every client shares one rate-limit bucket and audit IP")
check(env(base, "caddy").get("EARNIE_ACME_EMAIL"), "caddy needs an ACME contact in the default acme mode")
check(env(base, "caddy").get("EARNIE_TLS") == "acme", f"the bundle defaults to ACME certificates, got {env(base, 'caddy').get('EARNIE_TLS')!r}")
tls_mount = [v for v in svc(base, "caddy").get("volumes", []) if v.get("target") == "/etc/caddy/tls"]
check(tls_mount and tls_mount[0].get("read_only") and tls_mount[0].get("source", "").endswith("/tls"),
      f"caddy reads a custom certificate from EARNIE_DATA_DIR/tls, read-only: {tls_mount}")
check(svc(base, "caddy").get("healthcheck", {}).get("test"), "caddy needs a healthcheck so --wait notices a crash loop")
check(svc(base, "web").get("healthcheck", {}).get("test"), "web needs a healthcheck so caddy never proxies to a container that is starting or hung")
check(svc(base, "caddy").get("depends_on", {}).get("web", {}).get("condition") == "service_healthy", "caddy must wait for a healthy web")
caddyfile = open(os.path.join(bundle_dir, "Caddyfile")).read()
check("lb_try_duration" in caddyfile, "caddy must retry the web dial through a restart instead of answering an empty 502")

check(str(env(base, "web").get("PORT")) == "3000", f"web PORT must be 3000, got {env(base, 'web').get('PORT')}")
check("DB_URL" not in env(base, "web") and "JWT_SECRET" not in env(base, "web"), "web must not receive api secrets")
check({"EARNIE_PASSWORD_AUTH_ENABLED", "OIDC_ISSUER"} <= set(env(base, "web")), "web must receive the sign-in gates it mirrors")
check(not {"SCANS_MAX_UPLOAD_MB", "SCANS_MAX_SBOM_MB", "SCANS_UPLOAD_TIMEOUT_SECONDS"} & set(env(base, "web")),
      "web must not receive the upload knobs: next.config.ts reads env at build time, so a runtime value there is dead")
check(env(base, "caddy").get("SCANS_MAX_UPLOAD_MB") == "3072", f"caddy caps request bodies at the tenant's upload limit, got {env(base, 'caddy').get('SCANS_MAX_UPLOAD_MB')!r}")
caddyfile = open(os.path.join(bundle_dir, "Caddyfile")).read()
check(re.search(r"request_body\s*\{\s*max_size \{\$SCANS_MAX_UPLOAD_MB(:\d+)?\}MiB\s*\}", caddyfile),
      "the Caddyfile must cap request bodies from SCANS_MAX_UPLOAD_MB")
check("OIDC_CLIENT_SECRET" not in env(base, "web") and "OIDC_CLIENT_ID" not in env(base, "web"), "web must not receive OIDC client credentials")

check(env(base, "earnie-api").get("EARNIE_SKIP_MIGRATIONS") == "true", "api skips migrations; the migrate one-shot owns them")
check(svc(base, "migrate").get("command") == ["--migrate-only"], "migrate runs --migrate-only")
check(svc(onprem, "migrate").get("depends_on", {}).get("postgres", {}).get("condition") == "service_healthy", "with the onprem profile, migrate waits for postgres")
check(svc(base, "migrate").get("depends_on", {}).get("postgres", {}).get("required", True) is False, "outside the onprem profile the postgres dependency must be optional")
deps = svc(base, "earnie-api").get("depends_on", {})
check(deps.get("bootstrap", {}).get("condition") == "service_completed_successfully", "api waits for bootstrap to complete")

check("otel-collector" not in services(base), "no endpoint, no collector")
check("otel-collector" in services(telemetry), "a non-empty EARNIE_OTLP_ENDPOINT must add the collector")
o = svc(telemetry, "otel-collector")
check(o.get("profiles") == ["telemetry"], f"the collector must be behind the telemetry profile, got {o.get('profiles')}")
check(not o.get("env_file"), "the collector must not read tenant.env; it would receive every tenant secret")
check(set(env(telemetry, "otel-collector")) == {"EARNIE_TENANT", "EARNIE_HOST", "EARNIE_OTLP_ENDPOINT", "EARNIE_OTLP_AUTHORIZATION", "EARNIE_TELEMETRY_SCRAPE_TARGETS", "EARNIE_DATA_DIR"},
      f"the collector gets only its endpoint and labels, got {sorted(env(telemetry, 'otel-collector'))}")
check(env(telemetry, "otel-collector").get("EARNIE_OTLP_ENDPOINT") == "https://otlp.example.test/otlp", "the collector exports to the configured endpoint")
check(json.loads(env(telemetry, "otel-collector").get("EARNIE_TELEMETRY_SCRAPE_TARGETS", "[]")) == ["earnie-api:8080", "worker-crypto:9090"],
      f"the collector scrapes the api and only the workers bought, got {env(telemetry, 'otel-collector').get('EARNIE_TELEMETRY_SCRAPE_TARGETS')}")
user = str(o.get("user", ""))
check(user and user.split(":")[0] not in ("0", "root"), f"the collector must not run as root, got {user!r}")
sources = {v.get("source", "") for v in o.get("volumes", [])}
data_dir = env(telemetry, "otel-collector").get("EARNIE_DATA_DIR")
check(data_dir == "/var/lib/earnie", f"the collector learns the data dir to measure, got {data_dir!r}")
check({src for src in sources if src.startswith("/")} == {os.path.join(bundle_dir, "otel-collector.yaml"), "/proc", "/sys", f"{data_dir}/.fsprobe"},
      f"the collector mounts only its config, /proc, /sys and the two empty probe directories (statfs on them reports the whole disk): the host root reaches the docker socket, /var/lib/docker holds container env and the data dir holds customer code, got {sorted(sources)}")
check({v["target"] for v in o["volumes"] if v["source"].endswith(".fsprobe") or v["source"] == "fsprobe-root"} == {"/hostfs", f"/hostfs{data_dir}"},
      f"the probes mount where the filesystem scraper statfs's the root and the data volume, got {o['volumes']}")
pi = svc(telemetry, "fs-probe-init")
for name in ("otel-collector", "fs-probe-init"):
    inside = [v["source"] for v in svc(telemetry, name).get("volumes", []) if v.get("type") == "bind" and (v["source"] + "/").startswith(bundle_dir + "/") and v["source"] != os.path.join(bundle_dir, "otel-collector.yaml")]
    check(not inside, f"{name} must bind nothing in the bundle dir but its config: the tenant apply rsyncs --delete as an unprivileged user and cannot remove root-made directories, got {inside}")
check(any(v.get("type") == "volume" and v["source"] == "fsprobe-root" and v.get("read_only") for v in o["volumes"]), "the collector reads the root probe from a read-only named volume")
check(pi.get("profiles") == ["telemetry"] and pi.get("entrypoint", [None])[-1].startswith("mkdir -p ") and "&&" not in pi["entrypoint"][-1] and ";" not in pi["entrypoint"][-1],
      f"the probe init only makes directories (mkdir -p is idempotent), got {pi.get('entrypoint')}")
check(o["depends_on"].get("fs-probe-init", {}).get("condition") == "service_completed_successfully", "the probe directories exist before the collector starts")
fs_cfg = open(os.path.join(bundle_dir, "otel-collector.yaml")).read()
check(re.search(r"filesystem:.*?mount_points: \[\"/\", \"\$\{env:EARNIE_DATA_DIR\}\"\]", fs_cfg, re.S), "the filesystem scraper is limited to / and the data dir")
check(all(v.get("read_only") for v in o.get("volumes", [])), f"the collector mounts everything read-only, got {o.get('volumes')}")
check([(p.get("host_ip"), str(p.get("published")), p.get("target")) for p in o.get("ports", [])] == [("127.0.0.1", "24224", 24224)],
      f"the collector publishes only the fluentforward port, on the host loopback, got {o.get('ports')}")
for name, s in base["services"].items():
    lg = s.get("logging") or {}
    check(lg.get("driver") == "json-file" and lg.get("options", {}).get("max-size"), f"{name}: without telemetry logs stay on the host, bounded json-file, got {lg}")
for name, s in telemetry["services"].items():
    lg = s.get("logging") or {}
    if name == "otel-collector":
        check(lg.get("driver") == "json-file" and lg.get("options", {}).get("max-size"), "the collector keeps bounded json-file, it must not ship its own logs through itself")
        continue
    opts = lg.get("options", {})
    check(lg.get("driver") == "fluentd", f"{name}: with telemetry logs go to the collector, got {lg.get('driver')}")
    check(opts.get("fluentd-address") == "127.0.0.1:24224", f"{name}: the fluentd driver targets the collector's loopback port, got {opts.get('fluentd-address')}")
    check(opts.get("fluentd-async") == "true", f"{name}: the fluentd driver must be async, or a down collector fails container start")
    check(opts.get("fluentd-buffer-limit", "").isdigit() and int(opts["fluentd-buffer-limit"]) <= 16384, f"{name}: the driver buffer must be bounded, it lives in dockerd memory")
    check(not ({"max-size", "max-file"} & set(opts)), f"{name}: json-file options leaked into the fluentd driver, which rejects them: {sorted(opts)}")
    check(opts.get("labels") == "com.docker.compose.service", f"{name}: the service label names the logs' service.name")
    check(opts.get("fluentd-sub-second-precision") == "true", f"{name}: whole-second timestamps reorder a burst of lines in Loki")
    check("otel-collector" not in (s.get("depends_on") or {}), f"{name}: a service must not depend on the collector, or a collector that fails to start takes the app down")
check(set(telemetry["services"]) - set(crypto["services"]) == {"otel-collector", "fs-probe-init"}, "telemetry adds only the collector and its probe init")
def top_services(path):
    block = open(path).read().split("\nservices:\n", 1)[1].split("\n\n", 1)[0] if path.endswith("logs.yaml") else open(path).read().split("\nservices:\n", 1)[1]
    return set(re.findall(r"^  ([a-z0-9-]+):\s*$", block, re.M))
declared = top_services(os.path.join(bundle_dir, "compose.yaml"))
shipped = top_services(os.path.join(bundle_dir, "compose.logs.yaml"))
check(shipped == declared - {"otel-collector"}, f"every service but the collector ships its logs; missing from compose.logs.yaml: {sorted(declared - {'otel-collector'} - shipped)}")
check(os.path.exists(os.path.join(bundle_dir, "compose.logs.yaml")), "compose.logs.yaml ships in the bundle")
collector_cfg = open(os.path.join(bundle_dir, "otel-collector.yaml")).read()
check(re.search(r"logs:\s*\n\s*receivers: \[fluent_forward\]", collector_cfg), "the collector has a logs pipeline fed by fluent_forward")

caddy_directives = {line.strip() for line in open(os.path.join(bundle_dir, "Caddyfile"))}
for directive in ("header ?X-Frame-Options DENY", "header ?Content-Security-Policy \"frame-ancestors 'none'\""):
    check(directive in caddy_directives, f"the Caddyfile must deny framing on every response: missing {directive!r}")

if failures:
    print("\n".join("FAIL: " + f for f in failures)); sys.exit(1)
print("compose contract: ok")
PY

# render-env.sh selects the logs override only with an endpoint.
render oss false https://otlp.example.test/otlp >/dev/null
grep -qx "COMPOSE_FILE=compose.yaml:compose.logs.yaml" "$bundle/.env" || { echo "FAIL: telemetry on must select compose.logs.yaml"; exit 1; }
render oss false "" >/dev/null
grep -qx "COMPOSE_FILE=compose.yaml" "$bundle/.env" || { echo "FAIL: telemetry off must use compose.yaml alone"; exit 1; }
echo "logs override selection: ok"

for script in "$bundle"/*.sh; do bash -n "$script"; done
echo "scripts parse: ok"

# A malformed upload knob stops render-env.sh before Caddy or the api reads it.
for bad in 0 -5 3GB 0512 10000000; do
  sed -i "s/^SCANS_MAX_UPLOAD_MB=.*/SCANS_MAX_UPLOAD_MB=$bad/" "$env_file"
  if "$bundle/render-env.sh" >/dev/null 2>&1; then
    echo "FAIL: render-env.sh accepted SCANS_MAX_UPLOAD_MB=$bad"; exit 1
  fi
done
sed -i "s/^SCANS_MAX_UPLOAD_MB=.*/SCANS_MAX_UPLOAD_MB=/" "$env_file"
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh refused an empty SCANS_MAX_UPLOAD_MB, which means the default"; exit 1; }
echo "upload knob validation: ok"

# EARNIE_TLS: render-env.sh refuses a mode Caddy has no snippet for, and each
# mode without what it reads; the real Caddy then adapts both snippets.
tls_set() { sed -i "s|^EARNIE_TLS=.*|EARNIE_TLS=$1|; s|^EARNIE_ACME_EMAIL=.*|EARNIE_ACME_EMAIL=$2|; s|^EARNIE_TLS_DIR=.*|EARNIE_TLS_DIR=$3|" "$env_file"; }
refuses() { if "$bundle/render-env.sh" >/dev/null 2>&1; then echo "FAIL: render-env.sh accepted $1"; exit 1; fi; }
tls_dir="$work/tls-certs"
mkdir -p "$tls_dir"
tls_set selfsigned ops@example.com ""; refuses "EARNIE_TLS=selfsigned"
tls_set acme "" ""
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh must take the admin email as the ACME contact"; exit 1; }
grep -qx "EARNIE_ACME_EMAIL=admin@example.com" "$bundle/.env" || { echo "FAIL: .env must carry the derived ACME contact"; exit 1; }
sed -i "s/^EARNIE_INITIAL_ADMIN_EMAIL=.*/EARNIE_INITIAL_ADMIN_EMAIL=/" "$env_file"; refuses "EARNIE_TLS=acme without any contact address"
sed -i "s/^EARNIE_INITIAL_ADMIN_EMAIL=.*/EARNIE_INITIAL_ADMIN_EMAIL=admin@example.com/" "$env_file"
tls_set custom "" "$tls_dir"; refuses "EARNIE_TLS=custom without cert.pem and key.pem"
echo cert >"$tls_dir/cert.pem"; refuses "EARNIE_TLS=custom without key.pem"
echo key >"$tls_dir/key.pem"
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh refused EARNIE_TLS=custom with both files"; exit 1; }
custom_mount=$(cd "$bundle" && docker compose --project-name earnie-contract config --format json | python3 -c 'import json,sys; print([v["source"] for v in json.load(sys.stdin)["services"]["caddy"]["volumes"] if v["target"] == "/etc/caddy/tls"][0])')
[ "$custom_mount" = "$tls_dir" ] || { echo "FAIL: EARNIE_TLS_DIR must be what caddy mounts, got $custom_mount"; exit 1; }
adapt() { docker run --rm -e EARNIE_HOST=earnie.corp.internal -e EARNIE_TLS="$1" -e EARNIE_ACME_EMAIL="$2" \
  -v "$bundle/Caddyfile:/etc/caddy/Caddyfile:ro" caddy:2-alpine caddy adapt --config /etc/caddy/Caddyfile 2>/dev/null; }
adapt acme ops@example.com | grep -q '"email":"ops@example.com","module":"acme"' || { echo "FAIL: EARNIE_TLS=acme must issue through ACME"; exit 1; }
custom_json=$(adapt custom "" || true)
grep -q '"load_files":\[{"certificate":"/etc/caddy/tls/cert.pem","key":"/etc/caddy/tls/key.pem"' <<<"$custom_json" || { echo "FAIL: EARNIE_TLS=custom must load the mounted certificate"; exit 1; }
grep -q '"default_sni":"earnie.corp.internal"' <<<"$custom_json" || { echo "FAIL: a handshake without SNI must get the tenant certificate"; exit 1; }
if grep -q '"module":"acme"' <<<"$custom_json"; then echo "FAIL: EARNIE_TLS=custom must never contact an ACME CA"; exit 1; fi
tls_set acme ops@example.com ""
"$bundle/render-env.sh" >/dev/null
echo "tls modes: ok"

# A shared host: EARNIE_TLS=proxy puts Caddy behind the host's TLS proxy on a
# loopback port, and every host-wide resource takes the tenant's own value.
set_var() { sed -i "s|^$1=.*|$1=$2|" "$env_file"; }
set_var EARNIE_MODULES oss,crypto; set_var EARNIE_OTLP_ENDPOINT https://otlp.example.test/otlp
tls_set proxy "" ""; set_var CADDY_HTTP_PORT ""; refuses "EARNIE_TLS=proxy without CADDY_HTTP_PORT"
set_var CADDY_HTTP_PORT 18081; set_var API_BRIDGE_PORT 18181; set_var EARNIE_FLUENTD_PORT 24301
set_var SCANS_SANDBOX_SUBNET 172.30.2.0/24; set_var SCANS_SANDBOX_NETWORK earnie-sandbox-b; set_var SANDBOX_EGRESS_CHAIN EARNIE-SB-2
for bad in "API_BRIDGE_PORT 0" "API_BRIDGE_PORT 70000" "EARNIE_FLUENTD_PORT 24x" "SANDBOX_EGRESS_CHAIN earnie-sb" "SANDBOX_EGRESS_CHAIN EARNIE-SANDBOX-FOR-TENANT-BB" "SCANS_SANDBOX_NETWORK -bad"; do
  key=${bad%% *}; keep=$(sed -n "s/^$key=//p" "$env_file"); set_var $bad; refuses "$bad"; set_var "$key" "$keep"
done
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh refused a valid proxy tenant"; exit 1; }
grep -qx "COMPOSE_FILE=compose.yaml:compose.proxy.yaml:compose.logs.yaml" "$bundle/.env" || { echo "FAIL: EARNIE_TLS=proxy must select compose.proxy.yaml, got $(grep ^COMPOSE_FILE= "$bundle/.env")"; exit 1; }
(cd "$bundle" && docker compose --project-name earnie-b config --format json) | python3 -c '
import json, sys
cfg = json.load(sys.stdin)["services"]
failures = []
def check(cond, msg):
    if not cond: failures.append(msg)
def ports(name): return [(p.get("host_ip"), str(p.get("published")), p.get("target")) for p in cfg[name].get("ports", [])]
def env(name): return cfg[name].get("environment") or {}
check(ports("caddy") == [("127.0.0.1", "18081", 80)], f"behind the proxy Caddy publishes only plain http on the loopback, got {ports("caddy")}")
check(env("caddy").get("EARNIE_SITE_SCHEME") == "http://" and env("caddy").get("EARNIE_TRUSTED_PROXIES") == "private_ranges", f"caddy must serve http and trust the proxy, got {env("caddy")}")
check([p[1:] for p in ports("earnie-api")] == [("18181", 8080)], f"the api takes its own bridge port, got {ports("earnie-api")}")
for name in ("worker-crypto", "sandbox-egress"):
    check(env(name).get("SCANS_SANDBOX_STAGING_URL", "").endswith(":18181"), f"{name} reaches staging on the tenant bridge port, got {env(name).get("SCANS_SANDBOX_STAGING_URL")}")
check(env("worker-crypto").get("SCANS_SANDBOX_NETWORK") == "earnie-sandbox-b", "the worker builds on the tenant sandbox network")
check(env("sandbox-egress").get("SANDBOX_EGRESS_CHAIN") == "EARNIE-SB-2", "sandbox-egress names the tenant chains")
check(ports("otel-collector") == [("127.0.0.1", "24301", 24224)], f"the collector takes its own loopback port, got {ports("otel-collector")}")
check(cfg["web"]["logging"]["options"]["fluentd-address"] == "127.0.0.1:24301", "the fluentd driver targets the tenant collector port")
if failures:
    print("\n".join("FAIL: " + f for f in failures)); sys.exit(1)
'
proxy_json=$(docker run --rm -e EARNIE_HOST=earnie.corp.internal -e EARNIE_TLS=proxy -e EARNIE_SITE_SCHEME=http:// -e EARNIE_TRUSTED_PROXIES=private_ranges \
  -v "$bundle/Caddyfile:/etc/caddy/Caddyfile:ro" caddy:2-alpine caddy adapt --config /etc/caddy/Caddyfile 2>/dev/null)
grep -q '"listen":\[":80"\]' <<<"$proxy_json" || { echo "FAIL: EARNIE_TLS=proxy must serve plain http"; exit 1; }
if grep -qE '"module":"acme"|"load_files"' <<<"$proxy_json"; then echo "FAIL: EARNIE_TLS=proxy must hold no certificate"; exit 1; fi
grep -q '"trusted_proxies":{"ranges":\["192.168.0.0/16"' <<<"$proxy_json" || { echo "FAIL: EARNIE_TLS=proxy must trust the host proxy on a private address"; exit 1; }
grep -q '"trusted_proxies":{"ranges":\["127.0.0.1/32"\]' <<<"$(adapt acme ops@example.com)" || { echo "FAIL: without the proxy Caddy must trust no forwarded headers"; exit 1; }
rules=$(SANDBOX_EGRESS_CHAIN=EARNIE-SB-2 SCANS_SANDBOX_SUBNET=172.30.2.0/24 SCANS_SANDBOX_STAGING_URL=http://172.17.0.1:18181 sh "$bundle/sandbox-egress.sh" rules)
grep -qx -- "-A EARNIE-SB-2 -p tcp -m conntrack --ctstate DNAT --ctorigdst 172.17.0.1 --ctorigdstport 18181 -j RETURN" <<<"$rules" &&
  grep -qx -- "-A EARNIE-SB-2-NAT ! -d 172.30.2.0/24 -j MASQUERADE" <<<"$rules" &&
  ! grep -q "EARNIE-SANDBOX" <<<"$rules" || { echo "FAIL: SANDBOX_EGRESS_CHAIN must name every chain the tenant writes"; exit 1; }
for key in CADDY_HTTP_PORT API_BRIDGE_PORT EARNIE_FLUENTD_PORT SCANS_SANDBOX_SUBNET SCANS_SANDBOX_NETWORK SANDBOX_EGRESS_CHAIN; do
  set_var "$key" "$(sed -n "s/^$key=//p" "$bundle/tenant.env.example")"
done
set_var EARNIE_MODULES oss; set_var EARNIE_OTLP_ENDPOINT ""
tls_set acme ops@example.com ""
"$bundle/render-env.sh" >/dev/null
echo "shared host: ok"

# The sandbox-egress rules, as the host would load them. Every accept names a
# destination, registries get 80 and 443 only, and the chains end in a reject.
rules=$(SCANS_SANDBOX_SUBNET=172.31.250.0/24 SCANS_SANDBOX_STAGING_URL=http://172.17.0.1:8080 \
  SCANS_SANDBOX_MIRROR_CIDRS="10.9.0.0/16, 10.8.0.5/32" sh "$bundle/sandbox-egress.sh" rules)
python3 - "$rules" "$bundle/sandbox-registries.txt" <<'PY'
import ipaddress, sys
rules, registries = sys.argv[1].splitlines(), sys.argv[2]
failures = []
def check(cond, msg):
    if not cond: failures.append(msg)

forward = [r for r in rules if r.startswith("-A EARNIE-SANDBOX ")]
accepts = [r for r in forward if r.endswith("-j RETURN")]
check(forward[-1] == "-A EARNIE-SANDBOX -j REJECT --reject-with icmp-admin-prohibited", f"forward chain must end in a reject, ends {forward[-1]!r}")
check([r for r in rules if r.startswith("-A EARNIE-SANDBOX-IN ")][-1].endswith("-j REJECT --reject-with icmp-admin-prohibited"), "the host itself must be refused")
for r in accepts:
    check(" -d " in r or "--ctorigdst " in r or "--ctstate ESTABLISHED,RELATED" in r, f"an accept without a destination opens everything: {r}")
check("-A EARNIE-SANDBOX -p tcp -m conntrack --ctstate DNAT --ctorigdst 172.17.0.1 --ctorigdstport 8080 -j RETURN" in rules, "staging must be reachable through the api's published port")
check("-A EARNIE-SANDBOX -d 10.9.0.0/16 -j RETURN" in rules and "-A EARNIE-SANDBOX -d 10.8.0.5/32 -j RETURN" in rules, "every configured mirror must be reachable")
listed = [l.split("#")[0].strip() for l in open(registries) if l.split("#")[0].strip()]
check(len(listed) > 50, f"sandbox-registries.txt looks truncated: {len(listed)} ranges")
for cidr in listed:
    ipaddress.IPv4Network(cidr)
    check(f"-A EARNIE-SANDBOX -d {cidr} -p tcp -m multiport --dports 80,443 -j RETURN" in rules, f"registry range {cidr} must be allowed on 80 and 443 only")
check("-A EARNIE-SANDBOX-NAT ! -d 172.31.250.0/24 -j MASQUERADE" in rules, "sandbox-egress must add the NAT the worker's network leaves out")
if failures:
    print("\n".join("FAIL: " + f for f in failures)); sys.exit(1)
print(f"sandbox egress rules: ok ({len(accepts)} accepts, {len(listed)} registry ranges)")
PY

# The on-prem archive release.yml publishes holds exactly this list: every
# profile but ai, whose earnie-api-ai waits for the on-prem AI decision.
images=$("$source_bundle/images.sh" v1.2.3)
want="caddy:2-alpine
ghcr.io/scanoss/earnie/earnie-api:v1.2.3
ghcr.io/scanoss/earnie/earnie-web:v1.2.3
otel/opentelemetry-collector-contrib:0.161.0
postgres:16-alpine"
if [ "$images" != "$want" ]; then
  printf 'FAIL: images.sh must print exactly:\n%s\ngot:\n%s\n' "$want" "$images"; exit 1
fi
echo "on-prem image list: ok"

# The notifications KEK is optional (the api boots with channels disabled), but
# a malformed value stops the api, so render-env.sh says so first.
good_kek=$(printf '2%.0s' $(seq 1 64))
echo "EARNIE_NOTIFICATIONS_KEK_HEX=" >>"$env_file"
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh refused an empty EARNIE_NOTIFICATIONS_KEK_HEX"; exit 1; }
for bad in abc "$(printf 'g%.0s' $(seq 1 64))"; do
  echo "EARNIE_NOTIFICATIONS_KEK_HEX=$bad" >>"$env_file"
  if "$bundle/render-env.sh" >/dev/null 2>&1; then
    echo "FAIL: render-env.sh accepted EARNIE_NOTIFICATIONS_KEK_HEX='$bad'"; exit 1
  fi
done
echo "EARNIE_NOTIFICATIONS_KEK_HEX=$good_kek" >>"$env_file"
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh refused a valid EARNIE_NOTIFICATIONS_KEK_HEX"; exit 1; }
echo "notifications KEK validation: ok"

# cra is a module toggle like enrichment: render-env.sh accepts it and a
# misspelling is still refused.
sed -i "s/^EARNIE_MODULES=.*/EARNIE_MODULES=oss,cra/" "$env_file"
"$bundle/render-env.sh" >/dev/null || { echo "FAIL: render-env.sh refused the cra module"; exit 1; }
sed -i "s/^EARNIE_MODULES=.*/EARNIE_MODULES=oss,crra/" "$env_file"
if "$bundle/render-env.sh" >/dev/null 2>&1; then echo "FAIL: render-env.sh accepted the module crra"; exit 1; fi
echo "cra module validation: ok"
